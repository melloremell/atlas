#!/usr/bin/env python

import rospy
import json
import sys
from std_msgs.msg import String

pub = rospy.Publisher('/a2a/ms/hdl', String, queue_size=10)


def callback(msg):
        recv_data=msg.data
        print recv_data
        if recv_data == "wait":
            rospy.sleep(5)
            rospy.loginfo("Goal execution done!")
            json_string = """{"st":"0","act":"arm"}"""
            pub.publish(json_string)
        elif recv_data == "suspend":
            rospy.loginfo("Goal execution done!")
            json_string = """{"st":"0","act":"arm"}"""
            pub.publish(json_string)


if __name__ == '__main__':
    try:
        rospy.init_node('mission_skipper_py')
        rospy.Subscriber("/a2a/ms/skip", String, callback)
        rospy.spin()

    except rospy.ROSInterruptException:
        rospy.loginfo("Mission skipper finished.")