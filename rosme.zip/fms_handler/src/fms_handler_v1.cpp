#include "ros/ros.h"
#include "std_msgs/String.h"
#include "ArduinoJson.h"
#include <iostream>
#include <sstream>
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/NavSatFix.h>
#include <ctime>
#include <fstream>
#include <unistd.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/Image.h>
#include <std_msgs/Int32.h>
#include <sensor_msgs/LaserScan.h>
#include <stdlib.h>
#include <geometry_msgs/PoseStamped.h>

using namespace std;
using namespace std_msgs;
using namespace ros;

string AGV_ID = "AT200_1";

Publisher health_pub;
Publisher diag_pub;
Publisher slam_pt_pub;
Publisher encr_pub;
Publisher encl_pub;
Publisher sr_break_pub;
Publisher led_pub;
Publisher nav_pub;
Publisher arm_pub;
Publisher point_pub;
Publisher mv_pub;
Publisher skip_pub;

geometry_msgs::Twist sr_break;

int SR_SW = 0;
bool suspend = false;

int sr_led = 0;
int led_R = 0;
int led_G = 0;
int led_B = 0;

//yunus global
string ms_a="";
string ms_pt="";
string ms_x="";
string ms_y="";
string ms_z="";
string ms_w="";
string ms_st="5";
string ms_act="";
string ms_exe="";
string act_exe="";
string charge="";
string SR="";
string errHt="";
string othHt="";
string env_temp="";
string humid="";
string obu_id="";
string obu_temp="";



DynamicJsonBuffer msstobj_Buffer;
JsonVariant msstObj;

string ms_id = "";
int ms_cnt = 0;
int ms_max = 0;
string cur_lat= "";
string cur_long = "";
string cur_mapfname = "";
string ptsX="0.0";
string ptsY="0.0";

string ldr_2df = "", ldr_2dr = "", ldr_3d= "";
string batt = "";
string mot_l = "",mot_r = "";
string llc = "";
string obu = "";
string enc_l = "", enc_r = "";
string cam = "",cpu= "",ram = "",arm="";
string top ="";
string esw="";


Time llc_time;
Time lidar3_time;
Time lidar2f_time;
Time lidar2r_time;
Time cam_time;
Time obu_time;
Time arm_time;
Time health_t;


void process_mem_usage(double& vm_usage, double& resident_set)
{
    vm_usage     = 0.0;
    resident_set = 0.0;

    // the two fields we want
    unsigned long vsize;
    long rss;
    {
        std::string ignore;
        std::ifstream ifs("/proc/self/stat", std::ios_base::in);
        ifs >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore
                >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore
                >> ignore >> ignore >> vsize >> rss;
    }

    long page_size_kb = sysconf(_SC_PAGE_SIZE) / 1024; // in case x86-64 is configured to use 2MB pages
    vm_usage = vsize / 1024.0;
    resident_set = rss * page_size_kb;
}

void process_cpu_usage(double& cpu)
{
    cpu  = 0.0;

    {
        std::string ignore;
        std::ifstream ifs("/proc/loadavg", std::ios_base::in);
        ifs >> cpu >> ignore >> ignore >> ignore >> ignore;
    }

    cpu = cpu*100/6.0;
}

void publish_diagnostic()
{

  DynamicJsonBuffer jsonWriteBuffer;
  JsonObject& root = jsonWriteBuffer.createObject();

    // cout<<"in"<<endl; success output:in
  root["agv_ID"]= AGV_ID;
  // cout<<root["agv_ID"]<<endl; success output:1
  JsonObject& ldrObj = root.createNestedObject("ldr");
  ldrObj["2df"]= ldr_2df;
  // cout<<ldrObj["2df"]<<endl; success output:0
  ldrObj["2dr"]= ldr_2dr;
  // cout<<ldrObj["2dr"]<<endl; success output:0
  ldrObj["3d"]= ldr_3d;
  // cout<<ldrObj["3d"]<<endl; success output:0
  root["batt"]= batt;
  //cout<<root["batt"]<<endl; success output:""
  JsonObject& motObj = root.createNestedObject("mot");
  motObj["l"]=mot_l;
  // cout<<motObj["l"]<<endl; success output:""
  motObj["r"]=mot_r;
  // cout<<motObj["r"]<<endl; success output:""
  root["cam"]= cam;
  // cout<<root["cam"]<<endl; success output:0
  root["cpu"]= cpu;
  // cout<<root["cpu"]<<endl; success output:7.8333
  root["ram"]= ram;
  // cout<<root["ram"]<<endl; success output:335148:11044
  root["llc"]= llc;
  // cout<<root["llc"]<<endl; success output:0
  root["arm"]= arm;
  // cout<<root["arm"]<<endl; success output:0
  root["obu"]= obu;
  // cout<<root["arm"]<<endl; success output:0
  root["top"]= top;
  // cout<<root["arm"]<<endl; success output:0
  root["esw"]= esw;
  // cout<<root["obu"]<<endl; success output:0
  JsonObject& encObj = root.createNestedObject("enc");
  encObj["l"]=enc_l;
  // cout<<encObj["l"]<<endl; success output:" "
  encObj["r"]=enc_r;
  // cout<<encObj["r"]<<endl; success output:" "

  string tmpstr;
  root.printTo(tmpstr);
  // cout<<tmpstr<<endl; success
  //output: {"agv_ID":"1","ldr":{"2df":"0","2dr":"0","3d":"0"},
  //         "batt":"","mot":{"l":"","r":""},"cam":"0",
  //         "cpu":"3.33333","ram":"335148:10836","llc":"0",
  //         "arm":"0","obu":"0","enc":{"l":"","r":""}}

  String strt;
  strt.data = tmpstr;
  //cout<<strt<<endl; //success
  // output: data: {"agv_ID":"1","ldr":{"2df":"0","2dr":"0","3d":"0"},
  //                "batt":"","mot":{"l":"","r":""},"cam":"0",
  //                "cpu":"2.33333","ram":"335152:10956","llc":"0",
  //                "arm":"0","obu":"0","enc":{"l":"","r":""}}

  diag_pub.publish(strt);

}

//process and publish the diagnostic data to FMS when requested
void sys_diag_Callback(const std_msgs::String::ConstPtr& msg)
{
  // {"agv_ID" : "1",    "cmd"  : "1" }
  string out = msg->data.c_str();
  DynamicJsonBuffer jsonBufferSysDiag;
  JsonObject& doc = jsonBufferSysDiag.parseObject(out);
  //cout<<doc["agv_ID"].as<string>()<<endl; success output:1




  if(doc["agv_ID"]==AGV_ID)
  {
    //cout<<"in"<<endl;  success output:in

    if(doc["cmd"]=="1")
    {
      publish_diagnostic();
    }
  }
}

void lidar3Callback(const sensor_msgs::PointCloud2::ConstPtr& msg)
{
  lidar3_time = Time::now();
}

void lidar2fCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
{
  lidar2f_time = Time::now();
}

void lidar2rCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
{
  lidar2r_time = Time::now();
}

void camCallback(const sensor_msgs::Image::ConstPtr& msg)
{
  cam_time = Time::now();
}

void obuCallback(const std_msgs::String::ConstPtr& msg)
{
  obu_time = Time::now();
}

void armCallback(const geometry_msgs::PoseStamped::ConstPtr& msg)
{
  arm_time = Time::now();
}

void diag_check()
{
  //check ram
  double vm, rss;
  bool error = false;
  process_mem_usage(vm, rss);
  ostringstream ss,sw;
  ss << rss;
  sw << vm;
  ram = sw.str() + ":" + ss.str();

  //check cpu
  double cu;
  process_cpu_usage(cu);
  ostringstream cp;
  cp << cu;
  cpu = cp.str();


  //check camera
  Duration diff_c=Time::now()-cam_time;
  if(diff_c.toSec() > 5)
  {
    cam = "0";error = true;
  }
  else
  {
    cam = "1";
  }

  //check lidars
  Duration diffl3=Time::now()-lidar3_time;
  if(diffl3.toSec() > 5)
  {
    ldr_3d = "0";error = true;
  }
  else
  {
    ldr_3d = "1";
  }

  Duration diffl2f=Time::now()-lidar2f_time;
  if(diffl2f.toSec() > 5)
  {
    ldr_2df = "0";error = true;
  }
  else
  {
    ldr_2df = "1";
  }
  Duration diffl2r=Time::now()-lidar2r_time;
  if(diffl2r.toSec() > 5)
  {
    ldr_2dr = "0";error = true;
  }
  else
  {
    ldr_2dr = "1";
  }

  //check llc
  Duration diff=Time::now()-llc_time;
  if(diff.toSec() > 5)
  {
    llc = "0";error = true;
  }
  else
  {
    llc = "1";
  }

  //check obu
  Duration diffo=Time::now()-obu_time;
  if(diffo.toSec() > 5)
  {
    obu = "0";error = true;
  }
  else
  {
    obu= "1";
  }

  //check arm
  Duration diffar=Time::now()-arm_time;
  if(diffar.toSec() > 5)
  {
    arm = "0";error = true;
  }
  else
  {
    arm= "1";
  }
  if(error)
  {
    publish_diagnostic();
  }


}

//process and publish the health data to FMS periodically
//including all Suspend Resume stat
void agv_health_pub(const std_msgs::String::ConstPtr& msg)
{
  //get health data from here and there
  llc_time = Time::now();
  //publish it
  string sr_data = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferHealth;
  DynamicJsonBuffer jsonWriteBufferHealth;
  JsonObject& readObj = jsonReadBufferHealth.parseObject(sr_data);
  // cout<<readObj<<endl; success output: ___
  JsonObject& root = jsonWriteBufferHealth.createObject();
  root["agv_ID"] = AGV_ID;
  // cout<<root<<endl; success output: {"agv_ID":"1"}
  string tmpRenc = readObj["ENC?"][0];
  string tmpLenc = readObj["ENC?"][2];

  string motorX = readObj["MOV?"][0];
  string motorZ = readObj["MOV?"][1];

  // std_msgs::Int32 Le, Re;
  // Le.data = -1*atoi(tmpLenc.c_str());
  // // cout<<Le<<endl; success output: data: 0
  // Re.data = atoi(tmpRenc.c_str());
  // cout<<Re<<endl; success output: data: 0
  // encl_pub.publish(Le);
  // encr_pub.publish(Re);
  if(tmpRenc != ""){ enc_r = "1"; }

  else { enc_r = "0"; }

  if(tmpLenc != ""){ enc_l = "1"; }

  else { enc_l = "0"; }

  string tmpRT = readObj["STA?"][1];
  string tmpLT = readObj["STA?"][6];

  if(tmpRT != ""){ mot_r = "1"; }

  else { mot_r = "0"; }

  if(tmpLT!= ""){ mot_l = "1"; }

  else { mot_l = "0"; }

  string rawBatt = readObj["BAT?"];
  root["batt"] = rawBatt;
  batt = rawBatt;

  // string xS = readObj["MOV?"][0];
  // string zS = readObj["MOV?"][1];
  // string all = tmpRenc + "," + tmpLenc + "," + xS+ "," + zS;

  if (readObj["DI?"][3] == 0 && readObj["DI?"][3] ==  SR_SW )
  {
    SR_SW = readObj["DI?"][3];
    suspend = !suspend;
  }

  if (suspend)
  {
    sr_break_pub.publish(sr_break);
    sr_led = 1;
    led_R = 1;
    led_G = 0;
    led_B = 0;
    ms_st = "0";
    //cout << "Suspend -- Suspend -- Suspend -- Suspend --Suspend -- Suspend " << endl;
  }
  else
  {
    //case of move. Other case can add here
    sr_led = 0;
    led_R = 0;
    led_G = 1;
    led_B = 0;
    ms_st = "1";
    //cout << "Move -- Move -- Move -- Move -- Move -- Move -- Move -- Move " << endl;
  }

  JsonObject& msObj = root.createNestedObject("ms");
  msObj["MS_ID"] = ms_id;
  ostringstream ss;
  ss << ms_cnt;
  msObj["SCHED_ID"] = ss.str();
  ss << ms_cnt + 1;
  msObj["ACT_ID"] = ss.str();
  msObj["point"] = ms_pt;
  msObj["act"] = ms_act;
  msObj["ms_exe"] = ms_exe;
  msObj["act_exe"] = act_exe;

  root["charge"]=charge;
  root["SR"]=SR;

  JsonObject& msObj2 = root.createNestedObject("loc");
  msObj2["lat"]=cur_lat;
  msObj2["long"]=cur_long;

  JsonObject& msObj3 = root.createNestedObject("pnt");
  msObj3["x"]=ptsX;
  msObj3["y"]=ptsY;

  JsonObject& msObj4 = root.createNestedObject("spd");
  msObj4["x"]=motorX;
  msObj4["z"]=motorZ;

  JsonObject& msObj5 = root.createNestedObject("tmp");
  msObj5["l"]=tmpLT;
  msObj5["r"]=tmpRT;

  JsonObject& msObj6 = root.createNestedObject("sos");
  msObj["err"]=errHt;
  msObj["oth"]=othHt;

  JsonObject& msObj7 = root.createNestedObject("obj");
  msObj["env_temp"]=env_temp;
  msObj["humid"]=humid;
  msObj["obu_id"]=obu_id;
  msObj["obu_temp"]=obu_temp;

  string tmpstr;
  root.printTo(tmpstr);
  String strt;
  strt.data = tmpstr;
  // cout << strt << endl; success output: data: {"agv_ID":"1","batt":"",
  //                                              "ms":{"ID":"","f":"0","t":"01","s":"0"}}
  //                                              when move, s is 1
  Duration diff_c=Time::now()-health_t;
  if(diff_c.toSec() > 1)
  {
    //cout<<strt<<endl;
    health_pub.publish(strt);
    health_t = Time::now();
  }



  // String res;
  // res.data = all;
  // enc_pub.publish(res);

}

void mvSysCallback(const std_msgs::String::ConstPtr &msg)
{ //move robot using fms UI from server
  //{"agv_ID" : "1","x": "0.1","z": "0.1","cmd": "0/1"}
  //cmd 1 is start, 0 is stop
  string mvData = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferMvSys;
  JsonObject& readObj = jsonReadBufferMvSys.parseObject(mvData);
  // cout<<readObj["agv_ID"]<<endl; success output:1

  if(readObj["agv_ID"]== AGV_ID)
  {
    // cout<<"in"<<endl; success output:in
    if(readObj["cmd"]=="1")
    {
      // cout<<"in"<<endl; success when cmd is 1 output:in
      geometry_msgs::Twist move;
      move.linear.x = float(readObj["x"]);
      // cout<<readObj["x"]<<endl; success output:0.1
      // cout<<move.linear.x<<endl; success output:0.1
      move.linear.y = move.linear.z = 0.0;
      move.angular.x = move.angular.y = 0.0;
      move.angular.z = float(readObj["z"]);
      // cout<<move.angular<<endl; success output: x:0
      //                                           y:0
      //                                           z:0.1
      // cout<<move<<endl; success output: linear:
      //                                     x: 0.1
      //                                     y: 0
      //                                     z: 0
      //                                    angular:
      //                                     x: 0
      //                                     y: 0
      //                                     z: 0.1
      cout<<move<<endl;
      mv_pub.publish(move);
    }

  }
}


void ledCallback(const std_msgs::String::ConstPtr &msg)
{
  string Data = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferLedCall;
  JsonObject& readObj = jsonReadBufferLedCall.parseObject(Data);
  // cout<<readObj<<endl; success output:{"SR":0,"R":0,"G":0,"B":0}
}

void gpsCallback(const sensor_msgs::NavSatFixConstPtr& msg)
{
  std::ostringstream la,lo;
  lo << msg->longitude;
  la << msg->latitude;
  cur_long = lo.str();
  cur_lat = la.str();

}
void ptsCallback(const std_msgs::String::ConstPtr &msg){
  ptsX="30";
  ptsY="20";
}

void swCallback(const std_msgs::String::ConstPtr &msg){
  string swdata = msg->data.c_str();
  top = swdata[0];
  esw = swdata[1];
}

void slamCallback(const std_msgs::String::ConstPtr &msg)
{
  // from input:
  // {
  //   "cmd":"0/1/2",
  //   "area":"One North",
  //   "ptn":"point1"
  // }
  // 0: stop slam
  // 1: start slam
  // 2: insert point

  string mvData = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferSlam;
  JsonObject& readObj = jsonReadBufferSlam.parseObject(mvData);
  // cout<<readObj<<endl; success output:{"cmd":"1","area":"One North","ptn":"point1"}
  int a;
  if (readObj["cmd"]=="0")//stop slam and save the save map
  {
    // cout<<"in"<<endl; success output: in
    //                                   ERROR: Service [/hdl_graph_slam/save_map] is not available
    //                                   sh: 1: kill: No such process

    // save as cur_mapfname
    string dat = "rosservice call /hdl_graph_slam/save_map \" resolution: 0.05 \n destination: '/full_path_directory/"+cur_mapfname+".pcd'\" ";
    a = system(dat.c_str());
    //kill roslaunch
    a = system("kill -INT 7953");
  }
  else if (readObj["cmd"]=="1")//start slam
  {//http://answers.ros.org/question/10493/programmatic-way-to-stop-roslaunch/
    // cout<<"in"<<endl; success output:in
    //                                  [hdl_graph_slam_ends1.launch] is neither a launch file in package
    //                                  [hdl_graph_slam] nor is [hdl_graph_slam] a launch file name
    //                                  The traceback for the exception was written to the log file
    a = system("roslaunch hdl_graph_slam hdl_graph_slam_ends1.launch & roslaunch_PID=7953");
  }
  else if (readObj["cmd"]=="2")//insert slam point slam
  {
    // {
    //    “map_fname”: “One_North_757496869659”,
    //    “map_name”:”One North”
    //    “name”: “point1”,
    //    “loc” : {“x":”1.123”,”y”:”5.2121”},
    //    “gps” : {“lat":”1.123”,”long”:”5.2121”}
    // }
    DynamicJsonBuffer navBufferSlam;
    JsonObject& obj = navBufferSlam.createObject();
    string mapname = readObj["area"];
    obj["map_name"]= mapname;
    mapname.erase(remove_if(mapname.begin(), mapname.end(), ::isspace), mapname.end());
    time_t t = time(0);
    // cout<<t<<endl; success output:1570705276
    stringstream ss;
    ss << t;
    cur_mapfname = mapname+"_" + ss.str();//remove whitespace + unixtimestamp
    // cout<<cur_mapfname<<endl; success output: OneNorth_1570705455
    obj["map_fname"]= cur_mapfname;
    obj["name"]= readObj["ptn"];
    // cout<<obj<<endl; success output: OneNorth_1570705568
    JsonObject& cmd = obj.createNestedObject("loc");
    cmd["x"]="";//gather from slam
    cmd["y"]="";//gather from slam
    // cout<<cmd<<endl; success output: {"x":"","y":""}
    JsonObject& cm = obj.createNestedObject("gps");
    cm["lat"]=cur_lat;
    cm["long"]=cur_long;
    // cout<<cm<<endl; success output:{"lat":"","long":""}

    string root2;
    obj.printTo(root2);
    String s;
    s.data = root2;
    // cout<<s<<endl; success output: data: {"map_name":"One North",
    //                                "map_fname":"OneNorth_1570705791",
    //                                "name":"point1","loc":{"x":"","y":""},"gps":{"lat":"","long":""}}

    point_pub.publish(s);

  }

}

//start the mission from FMS web
void msstCallback(const std_msgs::String::ConstPtr &msg)
{

  //format of mqtt data to ros
//   {
//    "agv_ID": "1",
//    "ms_ID": "1",
//    "fname": "OneNorth_1351434245",
//    "activity": [
//       {
//          "pt":"point1"
//          "x": "0,5",
//          "y": "0.4",
//          "z": "0.4",
//          "w": "0.4",
//          "arm": {
//             "cmd": "pick1",
//             "j1": "273.49 163.35 65.14 359.13 260.16 185.65",
//             "fv1": "-5388 -5388",
//             "p1": "0.2834 0.0 0.08 0 0 90,0.0 -0.1572 0.0 0 0 0,0.0 0.0 -0.1408 0 0 0,0.0 0.0 0.0 0 0 0",
//             "fv2": "6250 6250",
//             "j2": "232.24 200.18 125.30 360.22 281.63 54.82",
//             "p2": "0.0 0.268 0.0 0 0 0,0.1278 0.0 0.0 0 0 0,0.0 0.179 0.0 10 0 0,0.0 0.0 -0.145 0 0 0",
//             "fv3": "-5394 -5394",
//             "j3": "167.25 198.22 120.15 361.88 280.52 -11.98",
//             "fv4": "5400 5400",
//             "j4": "269.19 84.68 39.73 359.89 239.92 354.67"
//          }
//       },
//       {
//          "pt":"point2"
//          "x": "0,5",
//          "y": "0.4",
//          "z": "0.4",
//          "w": "0.4",
//          "arm": {
//             "cmd": "pick2",
//             "j1": "273.49 163.35 65.14 359.13 260.16 185.65",
//             "fv1": "-5388 -5388",
//             "p1": "0.2834 0.0 0.08 0 0 90,0.0 -0.1572 0.0 0 0 0,0.0 0.0 -0.1408 0 0 0,0.0 0.0 0.0 0 0 0",
//             "fv2": "6250 6250",
//             "j2": "232.24 200.18 125.30 360.22 281.63 54.82",
//             "p2": "0.0 0.268 0.0 0 0 0,0.1278 0.0 0.0 0 0 0,0.0 0.179 0.0 10 0 0,0.0 0.0 -0.145 0 0 0",
//             "fv3": "-5394 -5394",
//             "j3": "167.25 198.22 120.15 361.88 280.52 -11.98",
//             "fv4": "5400 5400",
//             "j4": "269.19 84.68 39.73 359.89 239.92 354.67"
//          }
//       },
//    ]
// }


  //return json to navigation package
  // {
  //   "map":"filename",
  //   "to_x":"34.2",
  //   "to_y":"34.2"
  // }

  string Data = msg->data.c_str();
  msstObj = msstobj_Buffer.parseObject(Data);
  // cout<<msstObj["agv_ID"]<<endl; success output:1

  DynamicJsonBuffer navBuffer;
  JsonObject& obj = navBuffer.createObject();
  //cout<<msstObj<<endl;

  //cout<<msstObj<<endl;
  if(msstObj["agv_ID"]==AGV_ID)
  {
    //cout<<"in"<<endl;
    //cout<<msstObj["fname"]<<endl;
    // cout<<"in"<<endl;  success output:in
    JsonArray& msstptxy = msstObj["activity"];
    obj["map"] = msstObj["fname"];
    ms_max = msstptxy.size();
    //cout<<"Json msst"<<msstptxy<<endl;

    //cout<<ms_max<<endl; //success output:2
    ms_id = msstObj["ms_id"].as<string>();


    obj ["to_pt"] = msstptxy [0]["pt"].as<string>();

    obj ["to_x"] = msstptxy [0]["x"].as<string>();

    obj ["to_y"] = msstptxy [0]["y"].as<string>();

    obj ["to_z"] = msstptxy [0]["z"].as<string>();

    obj ["to_w"] = msstptxy [0]["w"].as<string>();

    string root2;
    obj.printTo(root2);
    // cout<<root2<<endl; success output:{"map":"OneNorth_1351434245",
    //                                    "to_x":"4.4","to_y":"5.5"}
    String s;
    s.data = root2;
    ms_st="1";
    nav_pub.publish(s);
    ms_pt = msstptxy [0]["pt"].as<string>();
    cout<<"Go To: "<<obj["to_pt"]<<endl;
  }

}

void navactCallback(const std_msgs::String::ConstPtr &msg)
{
  //cout<<"obj:"<<msstObj<<endl;
  // handling msg from navi or charge or arm:
  // {
  //   "st":"0",
  //   "to_y":"move/arm",
  // }
  string Data = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferNav;
  JsonObject& readObj = jsonReadBufferNav.parseObject(Data);
//cout<<readObj<<endl;
  // cout<<readObj<<endl; success output:{"to_x":"23.2","to_y":"23.2","st":"5"}

  DynamicJsonBuffer navBufferNav;
  JsonObject& nobj = navBufferNav.createObject();

  JsonArray& msstptxy = msstObj["activity"];
  //cout<<msstptxy<<endl; //success output:[]
  //check if current x and y for from and to point is run or done
  // to_x="23.2";
  // to_y="23.2";
  // to_z="23.2";
  // to_w="23.2";

    //cout<<"in"<<endl; failure cause: success if to_x and to_y initialize according to payload
    if(readObj["st"]== "0")//if task done
    {
      // cout<<"in"<<endl; failure cause:success if readObj["st"] is set according to payload
      if (ms_cnt < ms_max) //check within mission list
      {
        // cout<<"in"<<endl; failure cause: 1<0 IS WRONG
        //cout<<ms_st<<endl; success output:__
        if(readObj["act"]== "arm")//check type what is done: if arm is done, do move
        {
          ms_act="move";
          ms_pt = msstptxy [ms_cnt]["pt"].as<string>();
          ms_x = msstptxy [ms_cnt]["x"].as<string>();
          ms_y = msstptxy [ms_cnt]["y"].as<string>();
          ms_z = msstptxy [ms_cnt]["z"].as<string>();
          ms_w = msstptxy [ms_cnt]["w"].as<string>();
          //cout<<"in"<<endl; failure cause:__=="1" is wrong
          // cout<<nobj["map"]<<endl; success output:__ since msstObj output is []
          nobj["map"] = msstObj["fname"];
          nobj ["to_pt"] = ms_pt;
          nobj ["to_x"] = ms_x;
          nobj ["to_y"] = ms_y;
          nobj ["to_z"] = ms_z;
          nobj ["to_w"] = ms_w;

          string root2;
          nobj.printTo(root2);
          // cout<<root2<<endl; success output:{"map":,"to_x":"","to_y":""}
          String s;
          s.data = root2;
          ms_st="1";
          // cout<<s; success output: data: {"map":,"to_x":"","to_y":""}
          cout<<"Go To: "<<nobj["to_pt"]<<endl;
          nav_pub.publish(s);
        }
        else if(readObj["act"]== "move")//check type what is done: if move is done, do arm
        {
          ms_a = msstptxy [ms_cnt]["arm"].as<string>();
          if(ms_a=="wait")
          {
            cout<<"Waiting at: "<<msstptxy [ms_cnt]["pt"].as<string>()<<endl;
            String zw;
            zw.data="wait";
            skip_pub.publish(zw);

          }
          else if(ms_a=="suspend")
          {
            cout<<"Suspending at: "<<msstptxy [ms_cnt]["pt"].as<string>()<<endl;
            String zs;
            suspend = true;
            zs.data="suspend";
            skip_pub.publish(zs);
          }
          else
          {
            ms_act="arm";
            DynamicJsonBuffer meReadBuffer;
            JsonObject& armObj = meReadBuffer.parseObject(ms_a);

            string lt = armObj["cmd"];
            string first_four = lt.substr(0, 4);

            if(first_four == "pick")
            {
              ms_st="2";
              cout<<"Picking at: "<<msstptxy [ms_cnt]["pt"].as<string>()<<endl;
            }
            else
            {
              ms_st="3";
              cout<<"Droping at: "<<msstptxy [ms_cnt]["pt"].as<string>()<<endl;
            }

            String ss;
            ss.data = ms_a;
            // cout<<ss<<endl; success //output: data:{"agv_ID":"1","s":"2"}
            arm_pub.publish(ss);
          }


          ms_cnt ++;
        }
      }
      // else if (ms_cnt == ms_max)//go home
      // {
      //   nobj["map"] = msstObj["fname"];
      //   // cout<<nobj<<endl; failure cause:1==0 is wrong and appropriate payload release {"map":} output

      //   nobj ["to_x"] = msstptxy [0]["x"].as<string>();
      //   // cout<<to_x<<endl; success output:___
      //   nobj ["to_y"] = msstptxy [0]["y"].as<string>();
      //   // cout<<to_y<<endl; success output:___

      //   // cout<<nobj<<endl; success output:{"map":,"to_x":"","to_y":""}
      //   ms_st="0";
      //   string root2;
      //   nobj.printTo(root2);
      //   String s;
      //   s.data = root2;
      //   // cout<<s<<endl; success output: data: {"map":,"to_x":"","to_y":""}
      //   //cout<<"in"<<endl;
      //   nav_pub.publish(s);
      //   cout<<"Going Home at location 0"<<endl;
      //   ms_cnt++;
      // }
      else if (ms_cnt == ms_max)//reset all when mission finished
      {
        // cout<<"in"<<endl; total failure no output
        cout<<"ALL DONE"<<endl;
        ms_cnt = 0;
        ms_id = "";

      }
    }

}



void srCallback(const std_msgs::String::ConstPtr &msg)
{
  //{"agv_ID":"1", "cmd" :"1"}
  string Data = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferSr;
  JsonObject& readObj = jsonReadBufferSr.parseObject(Data);
  cout << "FMS SR REQ" << endl; //success output:FMS SR REQ
  // cout<<readObj["agv_ID"]<<endl; success output: 1
  if(readObj["agv_ID"]==AGV_ID)
  {
    // cout<<"in"<<endl; success output:in
    string text = readObj["cmd"];
    if (text == "1")
    {
      // cout<<text<<endl; success output:1
      suspend = !suspend;
    }
    else if(text == "0")
    {
      suspend = !suspend;
    }
    // cout<<suspend<<endl; success output display 1 for first launch and next display 0 and then 1 ...
  }

}

void ledpub()
{
  DynamicJsonBuffer jsonReadBuffer;
  JsonObject& readObj = jsonReadBuffer.createObject();

  readObj["SR"] = sr_led;
  readObj["R"] = led_R;
  readObj["G"] = led_G;
  readObj["B"] = led_B;

  string tmpstr;
  readObj.printTo(tmpstr);
  String strt;
  strt.data = tmpstr;
  led_pub.publish(strt);

}


void save()
{
  ofstream myfile("/home/mellore/catkin_ws/src/atlas200/config/AGVconfig.json");

  DynamicJsonBuffer jsonReadBufferled;
  JsonObject& readObjled = jsonReadBufferled.createObject();

  readObjled["SR"] = sr_led;
  readObjled["R"] = led_R;
  readObjled["G"] = led_G;
  readObjled["B"] = led_B;

  string tmpstr;
  readObjled.printTo(tmpstr);

  myfile <<tmpstr<<"\n";
  myfile.close();
}


void init()
{
  ifstream myReadFile;
  myReadFile.open("/home/mellore/catkin_ws/src/atlas200/config/AGVconfig.json");

  DynamicJsonBuffer jsonReadBufferSt;
  JsonObject& readObjSt = jsonReadBufferSt.parseObject(myReadFile);
  cout << readObjSt["car"] << endl;

  myReadFile.close();

  save();
}


int main(int argc, char **argv)
{

  ros::init(argc, argv, "fms_handler");
  ros::NodeHandle nh;

  sr_break.linear.x = sr_break.linear.y = sr_break.linear.z = 0.0;
  sr_break.angular.x = sr_break.angular.y = sr_break.angular.z = 0.0;

  //mission start (/f2a/ms/st) is listen directly by mission handler package;
  //arm movement data (/f2a/sys/arm) is listen directly by arm;
  //arm movement data (/f2a/sys/mv) is listen directly by agv;
  ros::Subscriber sys_diag = nh.subscribe("/f2a/sys/diag", 1000, sys_diag_Callback);
  ros::Subscriber healthSubs = nh.subscribe("/low_level/status", 1000, agv_health_pub);
  ros::Subscriber moveSubs = nh.subscribe("/f2a/sys/mv", 1000, mvSysCallback);
  ros::Subscriber ledSubs = nh.subscribe("/a2a/led", 1000, ledCallback);
  ros::Subscriber srSubs = nh.subscribe("/f2a/ms/sr", 1000, srCallback);
  ros::Subscriber msstSubs = nh.subscribe("/f2a/ms/st", 1000, msstCallback);
  ros::Subscriber navactSubs = nh.subscribe("/a2a/ms/hdl", 1000, navactCallback);
  ros::Subscriber slamSubs = nh.subscribe("/f2a/nav/map", 1000, slamCallback);
  ros::Subscriber gpsSubs = nh.subscribe("/gx5/gps/fix", 1000, gpsCallback);
  

  ros::Subscriber lidar3Subs = nh.subscribe("/os1_cloud_node/points", 1000, lidar3Callback);//listen 3D lidar
  ros::Subscriber lidar2fSubs = nh.subscribe("/cloud1", 1000, lidar2fCallback);//listen 2D Lidar f
  ros::Subscriber lidar2rSubs = nh.subscribe("/cloud2", 1000, lidar2rCallback);//listen 2D Lidar r
  ros::Subscriber camSubs = nh.subscribe("/camera/color/image_raw", 1000, camCallback);//listen camera
  ros::Subscriber obuSubs = nh.subscribe("/a2a/obu", 1000, obuCallback);//listen obu
  ros::Subscriber armSubs = nh.subscribe("/j2n6s200_driver/out/tool_pose", 1000, armCallback);//listen arm location

  //yunus creation
  ros::Subscriber ptsSubs = nh.subscribe("/a2a/pts", 1000, ptsCallback);
  ros::Subscriber swSubs = nh.subscribe("/a2a/sw", 1000, swCallback);


  skip_pub = nh.advertise<String>("/a2a/ms/skip", 1000);
  point_pub = nh.advertise<String>("/a2f/nav/pt", 1000);
  arm_pub = nh.advertise<String>("/f2a/arm/mv", 1000);
  nav_pub = nh.advertise<String>("/a2a/nav", 1000);
  led_pub = nh.advertise<String>("/a2a/led", 1000);
  health_pub = nh.advertise<String>("/a2f/ms/ht", 1000);
  diag_pub = nh.advertise<String>("/a2f/sys/diag", 1000);
  slam_pt_pub = nh.advertise<String>("/a2f/nav/pt", 1000);
  encl_pub = nh.advertise<std_msgs::Int32>("lwheel", 1000);
  encr_pub = nh.advertise<std_msgs::Int32>("rwheel", 1000);
  sr_break_pub = nh.advertise<geometry_msgs::Twist>("/high_level/twist_cmd_mux/input/sr", 1);
  mv_pub = nh.advertise<geometry_msgs::Twist>("/twist_cmd_mux/input/webop", 1000);

  health_t = Time::now();
  Rate loop_rate(50);

  while(ok())
  {
    //do task here
      //agv_health_pub();//periodically publish agv_health statue
    //diag_check();
    //ledpub();
    spinOnce();
    loop_rate.sleep();
  }
  return 0;
}
