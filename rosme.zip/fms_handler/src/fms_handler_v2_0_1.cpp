#include "ros/ros.h"
#include "std_msgs/String.h"
#include "ArduinoJson.h"
#include <iostream>
#include <sstream>
#include <string>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <sensor_msgs/NavSatFix.h>
#include <ctime>
#include <fstream>
#include <unistd.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/Image.h>
#include <std_msgs/Int32.h>
#include <sensor_msgs/LaserScan.h>
#include <stdlib.h>
#include <stdio.h>
#include <std_msgs/Empty.h>
#include <std_srvs/Empty.h>

#include <atlas80evo_msgs/SetONOFF.h>
#include <atlas80evo_msgs/SetSound.h>
#include <atlas80evo_msgs/SetFSMState.h>
#include <atlas80evo_msgs/FSMState.h>
#include <atlas80evo_msgs/SetFSMState.h>
#include <atlas80evo_msgs/SetPose2D.h>
#include <geometry_msgs/PoseStamped.h>

using namespace std;
using namespace std_msgs;
using namespace ros;

string ver = "FMS_Handler Version 2.0.1";
string AGV_ID = "AT200_1";

Publisher nav_pub;
Publisher arm_pub;
Publisher mv_pub;
Publisher skip_pub;
Publisher moveskipper_pub;
Publisher sched_pub;
Publisher arm_param_pub;
Publisher mscnt_pub;
Publisher msact_pub;
Publisher sus_pub;
Publisher sos_pub;
Publisher mstraycheck_pub;
Publisher msarm_pub;

ServiceClient shutdownClient;
ServiceClient findpickdropClient;
ServiceClient findchargerClient;
ServiceClient playsound;
ServiceClient findoutchargerClient;
ServiceClient stateClient;
ServiceClient findtableClient;
ServiceClient checkposeClient;
atlas80evo_msgs::SetSound srv;

bool juncfound = false;
bool firstNavi = true;
bool charging = false;
bool need_to_check_tray = false;
bool ready_to_pickdrop = false;
bool findTable_timer_lock = false;
bool done_abort = true;
bool done_arrived_home = false;

string ms_a="";
string ms_pt="";
string ms_act="done";
string ms_seq="";
string sched_id="";
string ss_id="";
string needcharge="0";
string esw = "1";
string ms_x="999";
string ms_y="999";
string ms_z="";
string ms_w="";
string ptsX = "";
string ptsY = "";
string tray [] = {"0","0","0","0"};
string armparam ="";

string cur_state="STANDBY";
string before_state="STANDBY";
string STATE = "STANDBY";


DynamicJsonBuffer msstobj_Buffer;
JsonVariant msstObj;
JsonVariant msstptxy_ref;

//General variable
bool move_skip = false;
string ms_id = "";
int ms_cnt = 0;
int ms_max = 0;

Time same_loc_delay;
Time findTable_timer;

//---------------------------------------------------------------------------------support functions----------------------------------------------
void goToHome();
void chargingroutine();
void callstate(string str);
void goOutHome();
void findPickDrop();
void findTable();
void NaviFirstActivity();
void mainloop();
void delaying_activity();
void same_point_skip();
void reset_naviparam();
void moving_routine();
void action_routine();
void action_gohome_routine();
void action_wait_routine();
void action_suspend_routine();
void action_arm_routine();
void abort_mission();
void reset_service();

bool check_tray(string before_or_after);
bool check_have_charger();
bool check_have_table();
bool findExit();
bool check_inside_home();


void mainloop()
{
  if(charging)
  {
    if(needcharge == "0")
    {
      cout<<"{F_HDLR} FULLCHARGED!!! Going back to mission."<<endl;
      charging = false;
      //goback to previous mission
      goOutHome();
    }
  }

  String sm;
  sm.data = ms_act;
  msact_pub.publish(sm);

  Int32 si;
  si.data = ms_cnt;
  mscnt_pub.publish(si);
}



void goToHome()
{
  DynamicJsonBuffer ghBuffer;
  JsonObject& ghobj = ghBuffer.createObject();
  ghobj["map"] = msstObj["fname"]["map"];
  ghobj ["to_pt"] = "Home";
  ghobj ["to_x"] = msstObj["fname"]["Home_x"];
  ghobj ["to_y"] = msstObj["fname"]["Home_y"];
  ghobj ["to_z"] = msstObj["fname"]["Home_z"];
  ghobj ["to_w"] = msstObj["fname"]["Home_w"];

  string root2;
  ghobj.printTo(root2);
  String s;
  s.data = root2;
  nav_pub.publish(s);//go to 1st location msstptxy [0]["pt"]
}

void chargingroutine()
{
  if(check_have_charger())
  {
    if(STATE != "CHARGING" && cur_state != "CHARGING")
    {
      callstate("CHARGING");
    }
    cout<<"{F_HDLR} Charger Found: Docking to charger now.."<<endl;
    cout<<"{F_HDLR} Calling service: /charging/call, awaiting callback"<<endl;
    atlas80evo_msgs::SetONOFF srvfc;
    srvfc.request.data = true;
    findchargerClient.call(srvfc);//service call to find charger
  }
  else
  {
    String x;
    x.data = "NoChargerError";
    sos_pub.publish(x);
    chargingroutine();
  }
}


void callstate(string str)
{
  if(str == "SUSPEND" || str == "MANUAL"){
    before_state = cur_state;
  }
  cur_state = str;
  // cout<<"BS:"<<before_state<<endl;
  // cout<<"S:"<<cur_state<<endl;
  atlas80evo_msgs::SetFSMState srvcall;
  srvcall.request.state = str.c_str();
  stateClient.call(srvcall);
}


void goOutHome()
{
  //go out of charger house
  atlas80evo_msgs::SetONOFF srvco;
  if(findExit() == true)
  {
    if(STATE != "LEAVING" && cur_state != "LEAVING")
    {
      callstate("LEAVING");
    }
    srvco.request.data = true;
    findoutchargerClient.call(srvco);
    cout<<"{F_HDLR} Go out of charging house..."<<endl;
    cout<<"{F_HDLR} Calling service: /leaving/call, awaiting callback"<<endl;
  }
  else
  {
    String x;
    x.data = "NoExit";
    sos_pub.publish(x);
    goOutHome();
  }
}

//find table before do navigate to table
void findPickDrop()
{
    //cout<<"Detecting Table with camera..."<<endl;
    if(check_have_table())//check can see table or not
    {
      cout<<"{F_HDLR} Calling service: /find_pickdrop/call, awaiting callback"<<endl;
      atlas80evo_msgs::SetONOFF srvft;
      srvft.request.data = true;
      findpickdropClient.call(srvft);
    }
    else
    {
      String x;
      x.data = "NoTableError";
      sos_pub.publish(x);
      findPickDrop();
    }

}

void findTable()
{
  Duration diff_dly=Time::now()-findTable_timer; 
  if(diff_dly.toSec() > 3)
  {
    atlas80evo_msgs::SetONOFF srvft;
    srvft.request.data = true;
    findtableClient.call(srvft);
    cout<<"{F_HDLR} Calling service: /aligning/call, awaiting callback"<<endl;
    findTable_timer_lock = false;
  }
  else
  {
    findTable_timer_lock = true;
    String s;
    s.data = "{\"st\":\"0\",\"act\":\"move\"}";
    sched_pub.publish(s);
  }
}


void NaviFirstActivity()
{
  if(STATE != "DELIVERY" && cur_state != "DELIVERY")
  {
    callstate("DELIVERY");
  }

  msstptxy_ref  = msstObj["activity"];
  ms_max = msstptxy_ref.size();
  sched_id = msstObj["sched_ID"].as<string>();
  ms_id = msstObj["ms_ID"].as<string>();
  ss_id = msstObj["ss_id"].as<string>();
  ms_seq = msstptxy_ref [0]["Seq"].as<string>();;
  ms_pt = "home";
  ms_act = "move";
  ms_x = msstptxy_ref [0]["x"].as<string>();
  ms_y = msstptxy_ref [0]["y"].as<string>();
  ms_pt = msstptxy_ref [0]["pt"].as<string>();

  DynamicJsonBuffer navBuffer;
  JsonObject& obj = navBuffer.createObject();
  obj["map"] = msstObj["fname"];
  obj ["to_pt"] = msstptxy_ref [0]["pt"].as<string>();
  obj ["to_x"] = msstptxy_ref [0]["x"].as<string>();
  obj ["to_y"] = msstptxy_ref [0]["y"].as<string>();
  obj ["to_z"] = msstptxy_ref [0]["z"].as<string>();
  obj ["to_w"] = msstptxy_ref [0]["w"].as<string>();
  string root2;
  obj.printTo(root2);
  String s;
  s.data = root2;
  nav_pub.publish(s);
  firstNavi = false;

  string ptp = obj["to_pt"].as<string>();
  cout<<"{F_HDLR} Go To: "+ptp <<endl;
}

void delaying_activity()
{
      //do loop of this callback till certain amount of time
    Duration diff_dly=Time::now()-same_loc_delay;  
    if(diff_dly.toSec() > 5)
    {
      ready_to_pickdrop = true;
      DynamicJsonBuffer dftBuffer;
      JsonObject& dftobj = dftBuffer.createObject();
      dftobj["st"] = "0";
      dftobj ["act"] = "move";
      string root2;
      dftobj.printTo(root2);
      String s;
      s.data = root2;
      cout<<"{F_HDLR} Action at same Point, skiping move and proceed to action"<<endl;
      sched_pub.publish(s);
    }
    else
    {
      String xm;
      xm.data = "{\"st\":\"1\",\"act\":\"bypass\"}";
      sched_pub.publish(xm);
    }
}

void reset_naviparam()
{
  cout<<"{F_HDLR} ALL ACTIVITIES DONE"<<endl;
  cout<<"{F_HDLR} -------------------------STANDBY-------------------------"<<endl<<endl;
  ms_cnt = 0;
  ms_id = "";
  ms_seq = "";
  ms_pt = "";
  ss_id = "";
  sched_id = "";
  ms_act = "done";
  msstObj = 0;
  firstNavi = true;
  ready_to_pickdrop = false;
  if(STATE != "STANDBY" && cur_state != "STANDBY")
  {
    callstate("STANDBY");
  }

}

bool check_tray(string before_or_after)//if true pass, NOERROR
{//check item in the tray for drop, check tray empty for pick
  if(need_to_check_tray)
  {
    if(before_or_after == "0")
    {
      string lt0 = msstptxy_ref [ms_cnt]["arm"]["cmd"].as<string>();
      string pd0 = lt0.substr(0, 4);
      string tsid0 = lt0.substr(4, sizeof(lt0));
      int traynum0 = atoi(tsid0.c_str());
      if(pd0 == "pick")
      {
        if(tray[traynum0-1]=="0")
        {
          return true;
        }
        else
        {
          String x;
          x.data = "PickError";
          sos_pub.publish(x);
          return false;
        }
      }
      else if(pd0 == "drop")
      {
        if(tray[traynum0-1]=="1")
        {
          return true;
        }
        else
        {
          String x0;
          x0.data = "DropError";
          sos_pub.publish(x0);
          return false;
        }
      }
    }
    else if(before_or_after == "1")
    {
      string lt1 = msstptxy_ref [ms_cnt-1]["arm"]["cmd"].as<string>();
      string pd1 = lt1.substr(0, 4);
      string tsid1 = lt1.substr(4, sizeof(lt1));
      int traynum1 = atoi(tsid1.c_str());
      if(pd1 == "pick")
      {
        if(tray[traynum1-1]=="1")
        {
          return true;
        }
        else
        {
          String x;
          x.data = "PickFail";
          sos_pub.publish(x);
          return false;
        }
      }
      else if(pd1 == "drop")
      {
        if(tray[traynum1-1]=="0")
        {
          return true;
        }
        else
        {
          String x1;
          x1.data = "DropFail";
          sos_pub.publish(x1);
          return false;
        }
      }
    }
  }
  else
  {
    return true;
  }
}

void moving_routine()
{
  if(check_tray("1"))
  {
    if(STATE != "DELIVERY" && cur_state != "DELIVERY")
    {
      callstate("DELIVERY");
    }
    string mx = msstptxy_ref [ms_cnt]["x"].as<string>();
    string my = msstptxy_ref [ms_cnt]["y"].as<string>();

    if(mx!=ms_x && my != ms_y)
    {
      ms_act="move";
      ms_seq = msstptxy_ref [ms_cnt]["Seq"].as<string>();
      ms_pt = msstptxy_ref [ms_cnt]["pt"].as<string>();

      ms_x = msstptxy_ref [ms_cnt]["x"].as<string>();
      ms_y = msstptxy_ref [ms_cnt]["y"].as<string>();
      ms_z = msstptxy_ref [ms_cnt]["z"].as<string>();
      ms_w = msstptxy_ref [ms_cnt]["w"].as<string>();


      DynamicJsonBuffer navBufferNav;
      JsonObject& nobj = navBufferNav.createObject();

      nobj["map"] = msstObj["fname"];
      nobj ["to_pt"] = ms_pt;
      nobj ["to_x"] = ms_x;
      nobj ["to_y"] = ms_y;
      nobj ["to_z"] = ms_z;
      nobj ["to_w"] = ms_w;

      string root2;
      nobj.printTo(root2);

      String s;
      s.data = root2;
      cout<<"{F_HDLR} Go To: "<<ms_pt<<endl;
      nav_pub.publish(s);
    }
    else
    {
      same_point_skip();
    }
  }
  else
  {
    moving_routine();
  }
}

void same_point_skip()
{
  ms_act="skip move";
  cout<<"{F_HDLR} Skipping Moving at same location.."<<endl;
  ms_seq = msstptxy_ref [ms_cnt]["Seq"].as<string>();
  ms_act = "move";
  move_skip = true;
}

void action_gohome_routine()
{
  ms_act="gohome";
  cout<<"{F_HDLR} Entering Charger House..."<<endl;
  ms_cnt ++;
  move_skip = false;
  chargingroutine();
}

void action_wait_routine()
{
  ms_act="wait";
  cout<<"{F_HDLR} Waiting at: "<<msstptxy_ref [ms_cnt]["pt"].as<string>()<<endl;
  String zw;
  zw.data="wait";
  skip_pub.publish(zw);
  ms_cnt ++;
  move_skip = false;
}

void action_suspend_routine()
{ 
  ms_act="suspend";
  cout<<"{F_HDLR} Requesting to suspend at: "<<msstptxy_ref [ms_cnt]["pt"].as<string>()<<endl;
  String zs;
  String mx;
  mx.data = "1";
  sus_pub.publish(mx);
  zs.data="suspend";
  skip_pub.publish(zs);
  ms_cnt ++;
  move_skip = false;
}

void action_arm_routine()
{
  if(STATE != "PICKDROP" && cur_state != "PICKDROP")
  {
    callstate("PICKDROP");
  }
  //check find table or not
  if(ready_to_pickdrop)
  {
    if(check_tray("0"))
    {
      String ss;
      ss.data = ms_a;
      cout<<"{F_HDLR} Arm Executing: "<<msstptxy_ref [ms_cnt]["arm"]["cmd"].as<string>()<<endl;
      msarm_pub.publish(ss);
      arm_pub.publish(ss);
      ms_cnt ++;
      move_skip = false;
      ready_to_pickdrop = false;
    }
    else
    {
      action_arm_routine();
    }
  }
  else
  {
    if(move_skip == false)//find table if not ready to pickdrop and not skiping move
    {
      if(!findTable_timer_lock)
      {
        findTable_timer = Time::now();
        cout<<"{F_HDLR} Waiting for Localization Stabilization before table alignment...."<<endl;
      }
      findTable();
    }
    else//of skipping move, go to delaying action
    {
      cout<<"{F_HDLR} Delaying the next PickDrop..."<<endl;
      same_loc_delay = Time::now();
      String xms;
      xms.data = "{\"st\":\"1\",\"act\":\"bypass\"}";
      sched_pub.publish(xms);
      
    }
  }    
}

void action_routine()
{
  ms_a = msstptxy_ref [ms_cnt]["arm"].as<string>();
  if(ms_a=="gohome")
  {
    action_gohome_routine();
  }
  else if(ms_a=="wait")
  {
    action_wait_routine();
  }
  else if(ms_a=="suspend")
  {
    action_suspend_routine();
  }
  else//arm action
  {
    action_arm_routine();            
  }  
}

void reset_service()
{
  atlas80evo_msgs::SetONOFF srvft;
  srvft.request.data = false;
  findtableClient.call(srvft);
  findpickdropClient.call(srvft);
  findchargerClient.call(srvft);
  findoutchargerClient.call(srvft);
}


void abort_mission()
{
  if(done_abort == true)
  {
    done_abort = false;
    cout<<"{F_HDLR} Aborting mission, going back home"<<endl;
    goToHome();
    msstObj=0;
    msstptxy_ref=0;
    reset_service();
  }
}

bool check_have_charger()
{
  return true;
}

bool check_have_table()
{
  return true;
}

bool findExit()
{
  return true;
}

bool check_inside_home()
{
  string ms_x = msstObj["fname"]["Home_x"].as<string>();
  string ms_y = msstObj["fname"]["Home_y"].as<string>();
  float dx = atof(ptsX.c_str())-atof(ms_x.c_str());
  float dy = atof(ptsY.c_str())-atof(ms_y.c_str());
  float distxy = sqrt(pow(dx,2)+pow(dy,2));

  if(distxy < 3.0 && distxy > 1.0)
  {
    return true;
  }
  else
  {
    return false;  
  }
}

//---------------------------------------------------------------------------------service server----------------------------------------------

//Server callback when charging Navigation to Charging Dock Done
bool DoneFindChargingDockCallback(std_srvs::Empty::Request& request, std_srvs::Empty::Response& response)
{
  if(ms_act=="gohome")
  {
    String s;
    s.data = "{\"st\":\"0\",\"act\":\"arm\"}";
    sched_pub.publish(s);
  }
  
  if(needcharge == "1")
  {
    charging = true;
    cout<<"{F_HDLR} Charging Now!!! Going back to mission in a while"<<endl;
  }

  if(done_abort == false)
  {
    done_abort = true;
    reset_naviparam();
  }

  return true;
}

//will be called after AGV get out of the Charging house, then proceed with navigation
bool DoneFindOutChargingDockCallback(std_srvs::Empty::Request& request, std_srvs::Empty::Response& response)
{
  if(firstNavi)
  {
    NaviFirstActivity();
  }
  else
  {
    String s;
    s.data = "{\"st\":\"0\",\"act\":\"arm\"}";
    sched_pub.publish(s);
  }
  return true;
}

//will be called after table alignment
bool DoneFindPickupCallback(atlas80evo_msgs::SetPose2D::Request& request, atlas80evo_msgs::SetPose2D::Response& response)
{
  ready_to_pickdrop = true;

  Duration(0.5).sleep(); 
  atlas80evo_msgs::SetPose2D srvft;
  srvft.request.x = request.x;
  srvft.request.y = request.y;
  srvft.request.theta = request.theta;
  checkposeClient.call(srvft);
  cout<<"{F_HDLR} Checking pose for arm..."<<endl;
  cout<<"{F_HDLR} Calling service: /check/pose, awaiting callback"<<endl;

  armparam = "";
  DynamicJsonBuffer paramBuffer;
  JsonObject& paramobj = paramBuffer.createObject();
  ostringstream xx,yy,tt;
  xx << request.x;
  yy << request.y;
  tt << request.theta;
  paramobj["new_x"]=xx.str();
  paramobj["new_y"]=yy.str();
  paramobj["new_deg"]=tt.str();
  paramobj.printTo(armparam);

  return true;
}


//Server callback when find table for arm Done
bool DoneFindTableCallback(std_srvs::Empty::Request& request, std_srvs::Empty::Response& response)
{

  findPickDrop();
  cout<<"{F_HDLR} Table Aligned: Proceed to Find PickDrop Point"<<endl;
  cout<<"{F_HDLR} Calling service: /find_pickdrop, awaiting callback"<<endl;

  return true;
}

//Server callback when checkpose done
bool DoneCheckPoseCallback(atlas80evo_msgs::SetONOFF::Request& request, atlas80evo_msgs::SetONOFF::Response& response)
{
  if(request.data == true)
  {
    //do pickdrop
    String param;
    param.data = armparam;
    arm_param_pub.publish(param);
    cout<<"{F_HDLR} PD Pose TRUE: Sending "<<armparam<<endl;
    Duration(1).sleep();
    //pickup action to arm
    DynamicJsonBuffer dftBuffer;
    JsonObject& dftobj = dftBuffer.createObject();
    dftobj["st"] = "0";
    dftobj ["act"] = "move";
    string root2;
    dftobj.printTo(root2);
    String s;
    s.data = root2;
    cout<<"{F_HDLR} Parameter Successfully Sent, Executing PickDrop"<<endl;
    sched_pub.publish(s);
  }
  else
  {
    //do table align call
    cout<<"{F_HDLR} PD Pose FALSE, Executing table align again"<<endl;
    cout<<"{F_HDLR} Calling service: /aligning/call, awaiting callback"<<endl;
    atlas80evo_msgs::SetONOFF srvft;
    srvft.request.data = true;
    findtableClient.call(srvft);
  }

  return true;
}

//---------------------------------------------------------------------------------ros callbacks----------------------------------------------

void trayCallback(const std_msgs::String::ConstPtr& msg)
{

  string tr_data = msg->data.c_str();
  DynamicJsonBuffer jsonReadBuffertray;
  JsonObject& readTRObj = jsonReadBuffertray.parseObject(tr_data);

  tray [0] = readTRObj["t1"].as<string>();
  tray [1] = readTRObj["t2"].as<string>();
  tray [2] = readTRObj["t3"].as<string>();
  tray [3] = readTRObj["t4"].as<string>();
}

void needchargeCallback(const std_msgs::String::ConstPtr &msg)
{
  needcharge = msg->data.c_str();

}


//entering Teleop
void TeleOPCallback(const std_msgs::String::ConstPtr &msg)
{
  string manData = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferMvMan;
  JsonObject& readObj = jsonReadBufferMvMan.parseObject(manData);

  if(readObj["agv_ID"]== AGV_ID)
  {
    if(readObj["status"]== "0")
    {
      if(STATE != before_state && cur_state != before_state)
      {
        callstate(before_state);
      }
    }
    else if(readObj["status"]== "1")
    {
      if(STATE != "MANUAL" && cur_state != "MANUAL")
      {
        callstate("MANUAL");
      }
    }

  }

}

//Handlin TeleOP of AGV
void mvSysCallback(const std_msgs::String::ConstPtr &msg)
{
  string mvData = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferMvSys;
  JsonObject& readObj = jsonReadBufferMvSys.parseObject(mvData);

  if(readObj["agv_ID"]== AGV_ID)
  {
    if(readObj["cmd"]=="1")
    {
      if(esw != "0")
      {
        geometry_msgs::Twist move;
        move.linear.x = float(readObj["x"]);
        move.linear.y = move.linear.z = 0.0;
        move.angular.x = move.angular.y = 0.0;
        move.angular.z = float(readObj["z"]);
        cout<<move<<endl;
        mv_pub.publish(move);
      }
    }

  }
}


void sys_off_Callback(const std_msgs::String::ConstPtr &msg){
  string off = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferOff;
  JsonObject& readObjO = jsonReadBufferOff.parseObject(off);

  if (readObjO["agv_ID"]==AGV_ID)//check ID
  {
    if (readObjO["status"] == "shutdown")//Check command
    {
      //call python shutdown service
      std_srvs::Empty srv;
      shutdownClient.call(srv);

    }
  }
}

void state_Callback(const atlas80evo_msgs::FSMState &msg)
{
 STATE = msg.state.c_str();
}

void eswCallback(const std_msgs::String::ConstPtr &msg)
{
  esw = msg->data.c_str();
}

void abortCallback(const std_msgs::String::ConstPtr &msg)
{
  string abt = msg->data.c_str();
  if(abt == "1")
  {
    abort_mission();
  }
}

void srCallback(const std_msgs::String::ConstPtr &msg)//FMS SR
{
  //{"agv_ID":"1", "cmd" :"1"}
  string Data = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferSr;
  JsonObject& readObj = jsonReadBufferSr.parseObject(Data);
  cout << "{F_HDLR} FMS Triggered Suspend/Resume" << endl; //success output:FMS SR REQ
  // cout<<readObj["agv_ID"]<<endl; success output: 1
  if(readObj["agv_ID"]==AGV_ID)
  {
    // cout<<"in"<<endl; success output:in
    String sr;
    sr.data = readObj["cmd"].as<string>();
    sus_pub.publish(sr);
  }
}

void navactCallback(const std_msgs::String::ConstPtr &msg)//mission scheduler
{
  string Data = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferNav;
  JsonObject& readObj = jsonReadBufferNav.parseObject(Data);

  if(readObj["st"]== "0")//if task done
  {
    if (ms_cnt < ms_max) //check within mission list
    {
      if(readObj["act"]== "arm")//arm done, do move
      {
        //If in charging mode          
        if(needcharge=="1" && done_arrived_home == false)
        {
          cout<<"{F_HDLR} LOW BATTERY!!! Going back to charge."<<endl;
          done_arrived_home = true;
          goToHome();
        }
        else
        {//before do next move, check pick/drop success or not
          moving_routine();
        }
      }
      if(readObj["act"]== "move" || move_skip == true)//move done, do action
      {
        if( (needcharge=="1" && done_arrived_home == true) || done_abort == false)
        {
          // charging routine from anywehere 
          done_arrived_home = false;       
          chargingroutine();
        }
        else
        {
          action_routine();   
        }    
      }//if(move DONE)
    }
    else if (ms_cnt == ms_max)//reset all when mission finished
    {
      reset_naviparam();
    }
  }//Check task done
  else //if st == 1
  {
    delaying_activity();
  }

}

void ptsCallback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msgAMCL){
  ostringstream px,py;
  float pX = msgAMCL->pose.pose.position.x;
  float pY = msgAMCL->pose.pose.position.y;
  px << pX;
  py << pY;
  ptsX = px.str();
  ptsY = py.str();

}


//start the mission from FMS web
void msstCallback(const std_msgs::String::ConstPtr &msg)
{
  if(ms_act=="done")
  {
    string Data = msg->data.c_str();
    msstObj = msstobj_Buffer.parseObject(Data);
    if(msstObj["agv_ID"]==AGV_ID)
    {
      if(check_inside_home())
      {
        goOutHome();
      }
      else
      {
        NaviFirstActivity();
      }
    }
  }
  else
  {
    cout<<"{F_HDLR} Ignoring Mission During An Active Mission"<<endl;
  }

}


int main(int argc, char **argv)
{

  init(argc, argv, "fms_handler");
  NodeHandle nh;

  sus_pub = nh.advertise<String>("/a2a/ms/sr", 100);
  mstraycheck_pub = nh.advertise<String>("/a2a/ms/traycheck", 100);
  msact_pub = nh.advertise<Int32>("/a2a/ms/act", 100);
  mscnt_pub = nh.advertise<String>("/a2a/ms/cnt", 100);
  sched_pub = nh.advertise<String>("/a2a/ms/hdl", 100);
  skip_pub = nh.advertise<String>("/a2a/ms/skip", 100);
  msarm_pub = nh.advertise<String>("/a2a/ms/arm", 100);
  sos_pub = nh.advertise<String>("/a2a/ms/sos", 100);
  arm_pub = nh.advertise<String>("/f2a/arm/mv", 100);
  nav_pub = nh.advertise<String>("/a2a/nav", 100);
  mv_pub = nh.advertise<geometry_msgs::Twist>("/twist_cmd_mux/input/webop", 100);

  Subscriber state = nh.subscribe("/fsm_node/state", 100, state_Callback);
  Subscriber sys_off = nh.subscribe("/f2a/sys/off", 100, sys_off_Callback);
  Subscriber moveSubs = nh.subscribe("/f2a/sys/mv", 100, mvSysCallback);
  Subscriber msstSubs = nh.subscribe("/f2a/ms/st", 100, msstCallback);
  Subscriber navactSubs = nh.subscribe("/a2a/ms/hdl", 100, navactCallback);
  Subscriber Manstart = nh.subscribe("/f2a/sys/man", 100, TeleOPCallback); 
  Subscriber needchargesubs = nh.subscribe("/a2a/ms/needcharge", 100, needchargeCallback); 
  Subscriber eswsubs = nh.subscribe("/a2a/ms/esw", 100, eswCallback); 
  Subscriber srSubs = nh.subscribe("/f2a/ms/sr", 1000, srCallback);
  Subscriber ptsSubs = nh.subscribe("/amcl_pose", 1000, ptsCallback);
  Subscriber traySubs = nh.subscribe("/a2f/arm/tray", 100, trayCallback);
  Subscriber abortSubs = nh.subscribe("/a2a/ms/abort", 100, abortCallback);

  shutdownClient = nh.serviceClient<std_srvs::Empty>("/shutdown");
  findpickdropClient = nh.serviceClient<atlas80evo_msgs::SetONOFF>("/find_pickdrop");
  findchargerClient = nh.serviceClient<atlas80evo_msgs::SetONOFF>("/charging/call");
  playsound = nh.serviceClient<atlas80evo_msgs::SetSound>("/sound/call");
  findoutchargerClient = nh.serviceClient<atlas80evo_msgs::SetONOFF>("/leaving/call");
  stateClient = nh.serviceClient<atlas80evo_msgs::SetFSMState>("/fsm_node/set_state");
  findtableClient = nh.serviceClient<atlas80evo_msgs::SetONOFF>("/aligning/call");  
  checkposeClient = nh.serviceClient<atlas80evo_msgs::SetPose2D>("/check/pose");

  ServiceServer donecheckpose_serv = nh.advertiseService("/check/reply", DoneCheckPoseCallback);
  ServiceServer donepickdrop_serv = nh.advertiseService("/find_pickdrop/goal", DoneFindPickupCallback);
  ServiceServer donecharger_serv = nh.advertiseService("/charging/done", DoneFindChargingDockCallback);
  ServiceServer doneoutcharger_serv = nh.advertiseService("/leaving/done", DoneFindOutChargingDockCallback);
  ServiceServer donetable_serv = nh.advertiseService("/aligning/done", DoneFindTableCallback);

  Rate loop_rate(20);
  cout <<"{F_HDLR} "<< ver << endl;
  same_loc_delay = Time::now();

  while(ok())
  {
    mainloop();
    spinOnce();
    loop_rate.sleep();
  }
  return 0;
}