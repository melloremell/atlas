#include "ros/ros.h"
#include "std_msgs/String.h"
#include "ArduinoJson.h"
#include <iostream>
#include <sstream>
#include <string>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <sensor_msgs/NavSatFix.h>
#include <ctime>
#include <fstream>
#include <unistd.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/Image.h>
#include <std_msgs/Int32.h>
#include <sensor_msgs/LaserScan.h>
#include <stdlib.h>
#include <stdio.h>
#include <std_msgs/Empty.h>
#include <std_srvs/Empty.h>

#include <atlas80evo_msgs/SetONOFF.h>
#include <atlas80evo_msgs/SetSound.h>
#include <atlas80evo_msgs/SetFSMState.h>
#include <atlas80evo_msgs/FSMState.h>
#include <atlas80evo_msgs/SetFSMState.h>
#include <atlas80evo_msgs/SetPose2D.h>
#include <geometry_msgs/PoseStamped.h>



using namespace std;
using namespace std_msgs;
using namespace ros;



string ver = "FMS_Health Version 1.0.0";
string AGV_ID = "AT200_1";

Publisher health_pub;
Publisher diag_pub;
Publisher led_pub;
Publisher sos_pub;
Publisher to_obu_pub;
Publisher sr_break_pub;
Publisher armxtra_pub;
Publisher arm_pub;
Publisher sus_pub;
Publisher reg_pub;
Publisher needcharge_pub;
Publisher esw_pub;
Publisher abort_pub;

ServiceClient playsound;
ServiceClient stateClient;
ServiceClient gochargeClient;



atlas80evo_msgs::SetSound srv;

geometry_msgs::Twist sr_break;

int SR_SW = 0;
bool suspend = false;
float max_charge = 100.0;
float low_charge = 45.0;
float junc_offset = 1.2;
float last_pX = 0.0;
float last_pY = 0.0;
float last_encL = 0.0;
float last_encR = 0.0;
float distPXY = 0.0;
float distENC = 0.0;
float MoveSOS_XYtoENC_Err = 10.0;
int batt_int = 0;
int RainFall = 1;
int HighHumidity = 50;
int sr_led = 0;
int batt_cnt = 0;
bool error = false;
bool wait = false;
bool waita = false;


bool NoTableError = false;
bool NoChargerError = false;
bool HumidSOS = false;
bool RainSOS = false;
bool OfflineSOS = false;
bool NoExit = false;
bool stopobs = false;
bool found_charger = false;



string ms_act="";
string ms_seq="";
string ms_id = "";
string sched_id="";
string ss_id="";
int ms_cnt = 0;


string needcharge="0";
string SR="0";
string sos_ID="";
string sos_type="";
string env_temp="";
string humid="";
string obu_id="";
string obu_temp="";
string rain="";
string cur_obj_detected ="4.0";
string cur_state="STANDBY";
string before_state="STANDBY";
string STATE = "STANDBY";

vector<string> sosID;
vector<int>sosID_enum;


DynamicJsonBuffer msstobj_Buffer;
JsonVariant msstObj;
JsonVariant msstptxy_ref;


string cur_lat= "";
string cur_long = "";
string cur_arm = "";

string ptsX="0.0";
string ptsY="0.0";
bool DropError = false;
bool PickError = false;
bool DropFail = false;
bool PickFail = false;
bool juncfound = false;


//for diagnostic
string ldr_2df = "1", ldr_2dr = "1", ldr_3d= "1";
string batt = "";
string lowbatt = "1";
string mot_l = "1",mot_r = "1";
string llc = "1";
string obu = "1";
string enc_l = "1", enc_r = "1";
string cam = "1",cpu= "1",ram = "1",arm="1";
string esw="1";
string imu="1";
string tcam="1";
string tray="1";

Time llc_time;
Time lidar3_time;
Time lidar2f_time;
Time lidar2r_time;
Time cam_time;
Time obu_time;
Time arm_time;
Time health_t;
Time imu_time;
Time tray_time;
Time tcam_time;
Time sus_t;
Time wait_t;
Time waita_t;
Time obs_t;
Time alert_t;




string sos_ref[]={
"indexIncreaser",
"5e0e1358119f20805c774db8",//1
"5e0e1362119f20805c774db9",//2
"5e0e1370119f20805c774dba",//3
"5e0e1370119f20805c774dba",//4
"5e0e1394119f20805c774dbb",//5
"5e0e13a3119f20805c774dbc",//6
"5e0e13b3119f20805c774dbd",//7
"5e0e13bf119f20805c774dbe",//8
"5e0e13cb119f20805c774dbf",//9
"5e0e13d9119f20805c774dc0",//10
"5e0e13e8119f20805c774dc1",//11
"5e0e13fd119f20805c774dc2",//12
"5e0e1410119f20805c774dc3",//13
"5e0e141d119f20805c774dc4",//14
"5e0e1436119f20805c774dc5",//15
"5e0e1452119f20805c774dc6",//16
"5e0e1467119f20805c774dc7",//17
"5e1a3335fb289204edb2490b",//18
"5e1a3348fb289204edb2490d",//19
"5e1a335ffb289204edb2490f",//20
"5e1a336bfb289204edb24911",//21
"5e0e1480119f20805c774dc8",//22
"5e0e1495119f20805c774dc9",//23
"5e0e14a7119f20805c774dca",//24
"5e0e14bb119f20805c774dcb",//25
"5e0e14e4119f20805c774dcc",//26
"5e0e259b3d05532a38036794" //27 override
};

string sos_res_ref[]={
"indexIncreaser",
"Suspend",//1
"WaitAlarm",//2
"GoCharge",//3
"AbortGoHome",//4
"Wait",//5
"AbortSuspend"//6
};


//-------------------------------------------------GENERIC FUNCTIONS------------------------------
void callstate(string str);
int findres_enum(string sos_res);
void process_mem_usage(double& vm_usage, double& resident_set);
void process_cpu_usage(double& cpu);
void soswait();
void soswaitalarm();
void publish_diagnostic();
bool isOnline();
void sos_trigger_response(int res);
void sos_trigger_response_str(string res);
void sos_response(int sos_ID);
void sos_notify(string err_id);
void sos_check();
void generic_check();
void ledpub();


void callstate(string str)
{
  if(str == "ERROR"){
    before_state = cur_state;
  }
  cur_state = str;
  // cout<<"BS:"<<before_state<<endl;
  // cout<<"S:"<<cur_state<<endl;
  atlas80evo_msgs::SetFSMState srvcall;
  srvcall.request.state = str.c_str();
  stateClient.call(srvcall);
}

int findres_enum(string sos_res)
{
  int o = 99;
  int mx = sizeof(sos_res_ref)/sizeof(sos_res_ref[0]);
  for(int x = 0; x < mx;x++)
  {
    if(sos_res_ref[x]==sos_res)
    {
      o = x;
      break;
    }
  }
  return 0;
}


void process_mem_usage(double& vm_usage, double& resident_set)
{
    vm_usage     = 0.0;
    resident_set = 0.0;

    // the two fields we want
    unsigned long vsize;
    long rss;
    {
        std::string ignore;
        std::ifstream ifs("/proc/self/stat", std::ios_base::in);
        ifs >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore
                >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore >> ignore
                >> ignore >> ignore >> vsize >> rss;
    }

    long page_size_kb = sysconf(_SC_PAGE_SIZE) / 1024; // in case x86-64 is configured to use 2MB pages
    vm_usage = vsize / 1024.0;
    resident_set = rss * page_size_kb;
}

void process_cpu_usage(double& cpu)
{
    cpu  = 0.0;

    {
        std::string ignore;
        std::ifstream ifs("/proc/loadavg", std::ios_base::in);
        ifs >> cpu >> ignore >> ignore >> ignore >> ignore;
    }

    cpu = cpu*100/6.0;
}

void soswait()
{
  Duration diff_w=Time::now()-wait_t;
  if(diff_w.toSec() > 5)
  {
    wait_t = Time::now();
    wait = true;
  }

  if(wait)
  {
    sr_break_pub.publish(sr_break);
    cout<<"Waiting 5s..........."<<endl;
    wait = false;
  }
}

void soswaitalarm()
{
  Duration diff_wa=Time::now()-waita_t;
  if(diff_wa.toSec() > 5)
  {
    waita_t = Time::now();
    waita = true;
    srv.request.path2file = "/home/endstruct2/catkin_ws/src/atlas80evo/sounds/pleasemove.wav";
    srv.request.channel = 1;
    srv.request.volume = 1.0;
    srv.request.loop = -1;
    srv.request.interval = 0;
    playsound.call(srv);   
  }

  if(waita)
  {
    sr_break_pub.publish(sr_break);
    cout<<"Waiting and Alarm 5s....."<<endl;
    sr_break_pub.publish(sr_break);    
    srv.request.path2file = "/home/endstruct2/catkin_ws/src/atlas80evo/sounds/siren_beeping.ogg";
    srv.request.channel = 1;
    srv.request.volume = 1.0;
    srv.request.loop = -1;
    srv.request.interval = 0;
    playsound.call(srv);
    waita = false;
  }
}

void publish_diagnostic()
{

  DynamicJsonBuffer jsonWriteBuffer;
  JsonObject& root = jsonWriteBuffer.createObject();

  // cout<<"in"<<endl; success output:in
  root["agv_ID"]= AGV_ID;
  // cout<<root["agv_ID"]<<endl; success output:1
  JsonObject& ldrObj = root.createNestedObject("ldr");
  ldrObj["2df"]= ldr_2df;
  // cout<<ldrObj["2df"]<<endl; success output:0
  ldrObj["2dr"]= ldr_2dr;
  // cout<<ldrObj["2dr"]<<endl; success output:0
  ldrObj["3d"]= ldr_3d;
  // cout<<ldrObj["3d"]<<endl; success output:0
  root["batt"]= lowbatt;
  //cout<<root["batt"]<<endl; success output:""
  JsonObject& motObj = root.createNestedObject("mot");
  motObj["l"]=mot_l;
  // cout<<motObj["l"]<<endl; success output:""
  motObj["r"]=mot_r;
  // cout<<motObj["r"]<<endl; success output:""
  root["cam"]= cam;
  // cout<<root["cam"]<<endl; success output:0
  root["cpu"]= cpu;
  // cout<<root["cpu"]<<endl; success output:7.8333
  root["ram"]= ram;
  // cout<<root["ram"]<<endl; success output:335148:11044
  root["llc"]= llc;
  // cout<<root["llc"]<<endl; success output:0
  root["arm"]= arm;
  // cout<<root["arm"]<<endl; success output:0
  root["obu"]= obu;
  // cout<<root["arm"]<<endl; success output:0
  root["esw"]= esw;
  // cout<<root["arm"]<<endl; success output:0
  root["imu"]= imu;
  // cout<<root["arm"]<<endl; success output:0
  root["tray"]= tray;
  // cout<<root["arm"]<<endl; success output:0
  root["tcam"]= tcam;
  // cout<<root["obu"]<<endl; success output:0
  JsonObject& encObj = root.createNestedObject("enc");
  encObj["l"]=enc_l;
  // cout<<encObj["l"]<<endl; success output:" "
  encObj["r"]=enc_r;
  // cout<<encObj["r"]<<endl; success output:" "

  string tmpstr;
  root.printTo(tmpstr);
  // cout<<tmpstr<<endl; success
  //output: {"agv_ID":"1","ldr":{"2df":"0","2dr":"0","3d":"0"},
  //         "batt":"","mot":{"l":"","r":""},"cam":"0",
  //         "cpu":"3.33333","ram":"335148:10836","llc":"0",
  //         "arm":"0","obu":"0","enc":{"l":"","r":""}}
  String strt;
  strt.data = tmpstr;
  //cout<<strt<<endl; //success
  // output: data: {"agv_ID":"1","ldr":{"2df":"0","2dr":"0","3d":"0"},
  //                "batt":"","mot":{"l":"","r":""},"cam":"0",
  //                "cpu":"2.33333","ram":"335152:10956","llc":"0",
  //                "arm":"0","obu":"0","enc":{"l":"","r":""}}
  diag_pub.publish(strt);
}

bool isOnline()
{
  FILE *output;

  if(!(output = popen("/sbin/route -n | grep -c '^0\\.0\\.0\\.0'","r")))
  {
        return 1;
  }
  unsigned int i;
  int x = fscanf(output,"%u",&i);
  if(i==0)
  {
    OfflineSOS = true;
    //cout<<"offline"<<endl;
  }
  else if(i==1)
  {
    OfflineSOS = false;
    //cout<<"online"<<endl;
  }
  pclose(output);
  return 1;

}

void sos_trigger_response(int res)
{
  switch(res)
  {
    case 1://Suspend
    {
      suspend = true;
      cout<<"SOS Triggered: Suspend"<<endl;
      break;
    }
    case 2://Wait and alarm
    {
      soswaitalarm();
      cout<<"SOS Triggered: Wait Alarm"<<endl;
      break;
    }
    case 3://Go To Charge (AGV only)
    {
      //gotocharge handler by needcharge variable to FMS_handler
      cout<<"SOS Triggered: Go to charge"<<endl;
      break;
    }
    case 4://Abort Mission and go to Charge
    {
      cout<<"SOS Triggered: Abort! Cancel All go to Home"<<endl;
      String ed;
      ed.data = "1";
      abort_pub.publish(ed);

      msstObj = 0;//clear mission
      break;
    }
    case 5:
    {
      soswait();
      cout<<"SOS Triggered: Wait"<<endl;
      break;
    }
    case 6:
    {
      soswait();
      cout<<"SOS Triggered: Abort and Suspend"<<endl;
      suspend = true;
      break;
    }
  }
  //After trigger response, reset the error trigger
  PickError = false;
  DropError = false;
  PickFail = false;
  DropFail = false;
  juncfound = false;
  NoTableError=false;
  NoChargerError=false;
  HumidSOS = false;
  RainSOS = false;
  OfflineSOS = false;
  NoExit = false;
}

void sos_trigger_response_str(string res) 
{
  sos_trigger_response(findres_enum(res));
}

//apply response accordingly
void sos_response(int sos_ID)
{
  if(STATE != "ERROR" && cur_state != "ERROR")
    {
      callstate("ERROR");
    }
  switch(sos_ID)
  {
    case 1://SOS:Cam, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 2://SOS:Lidar3D, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 3://SOS:Lidar2DF, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 4://SOS:Lidar2DR, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 5://SOS:LLC, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 6://SOS:OBU, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 7://SOS:Arm, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 8://SOS:Imu, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 9://SOS:Tray, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 10://SOS:tcam, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 11://SOS:offline, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 12://SOS:short, Response: WaitAlarm(4)
    {
      sos_trigger_response(4);
      break;
    }
    case 13://SOS:long, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 14://SOS:rain, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 15://SOS:humidity, Response: AbortGoHome(3)
    {
      sos_trigger_response(3);
      break;
    }
    case 16://SOS:eswitch, Response: AbortSuspend(6)
    {
      sos_trigger_response(4);
      break;
    }
    case 17://SOS:derr, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 18://SOS:perr, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 19://SOS:dfail, Response: (1)
    {
      sos_trigger_response(1);
      break;
    }
    case 20://SOS:pfail, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 21://SOS:junc, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 22://SOS:notable, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 23://SOS:no charger, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 24://SOS:noexit, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 25://SOS:moveerr, Response: Suspend(1)
    {
      sos_trigger_response(1);
      break;
    }
    case 26://SOS:lowbatt, Response: Gocharge(2)
    {
      sos_trigger_response(2);
      break;
    }
  }
}

void sos_notify(string err_id)
{
  DynamicJsonBuffer jsonSosWriteBuffer;
  JsonObject& rosos = jsonSosWriteBuffer.createObject();
  rosos["agv_ID"]= AGV_ID;
  JsonArray& arr = rosos.createNestedArray("sos_ID");

  string ID="";
  if(err_id != "0")//if sos trigger coming from FMS
  {
    ID = err_id;
    arr.add(ID);
  }
  else
  {
    for(std::vector<string>::size_type i = 0; i != sosID.size(); i++) 
    {
      ID = sosID[i];
      arr.add(ID);
      //sos_response(sosID_enum[i]);
      //cout<<i<<":"<<sosID_enum[i]<<","<<sos_ref[i]<<","<<ID<<endl;
    }
    //cout<<endl;
  }

  //------------Shoot to FMS for NOTIFICATION--------------
  string tmpstr;
  rosos.printTo(tmpstr);
  String strt;
  strt.data = tmpstr;
  sos_pub.publish(strt);

  sosID.clear();
  sosID_enum.clear();
  error = false;

}

void sos_check()
{
  
  //-------------------------------Diagnostic Error SOS Publish------------
  //check ram
  double vm, rss;
  process_mem_usage(vm, rss);
  ostringstream ss,sw;
  ss << rss;
  sw << vm;
  ram = sw.str() + ":" + ss.str();

  //check cpu
  double cu;
  process_cpu_usage(cu);
  ostringstream cp;
  cp << cu;
  cpu = cp.str();


  //1check camera (1)------------------------OK
  Duration diff_c=Time::now()-cam_time;
  if(diff_c.toSec() > 5)
  {
    cam = "0";error = true;
    sosID.push_back(sos_ref[1]); 
    sosID_enum.push_back(1); 
    cout<<"SOS!: Camera Error"<<endl;
  }
  else
  {
    cam = "1";
  }

  //2check lidar3d (2)
  Duration diffl3=Time::now()-lidar3_time;
  if(diffl3.toSec() > 5)
  {
    ldr_3d = "0";error = true;
    sosID.push_back(sos_ref[2]);   
    sosID_enum.push_back(2); 
    cout<<"SOS!: Lidar3D Error"<<endl;
  }
  else
  {
    ldr_3d = "1";
  }

  //3check lidar2d front (3)
  Duration diffl2f=Time::now()-lidar2f_time;
  if(diffl2f.toSec() > 5)
  {
    ldr_2df = "0";error = true;
    sosID.push_back(sos_ref[3]); 
    sosID_enum.push_back(3); 
    cout<<"SOS!: Lidar2D Front Error"<<endl;  
  }
  else
  {
    ldr_2df = "1";
  }

  //4check lidar2d rear (4)
  Duration diffl2r=Time::now()-lidar2r_time;
  if(diffl2r.toSec() > 5)
  {
    ldr_2dr = "0";error = true;
    sosID.push_back(sos_ref[4]); 
    sosID_enum.push_back(4); 
    cout<<"SOS!: Lidar2D Rear Error"<<endl;  
  }
  else
  {
    ldr_2dr = "1";
  }

  //5check llc (5)
  Duration diff=Time::now()-llc_time;
  if(diff.toSec() > 5)
  {
    llc = "0";error = true;
    sosID.push_back(sos_ref[5]);  
    sosID_enum.push_back(5);  
    cout<<"SOS!: Low Level Controller Error"<<endl;
  }
  else
  {
    llc = "1";
  }

  //6check obu (6)
  Duration diffo=Time::now()-obu_time;
  if(diffo.toSec() > 5)
  {
    obu = "0";error = true;
    sosID.push_back(sos_ref[6]);  
    sosID_enum.push_back(6); 
    cout<<"SOS!: OBU Error"<<endl;
  }
  else
  {
    obu= "1";
  }

  //7check arm (7)
  Duration diffar=Time::now()-arm_time;
  if(diffar.toSec() > 5)
  {
    arm = "0";error = true;
    sosID.push_back(sos_ref[7]);  
    sosID_enum.push_back(7); 
    cout<<"SOS!: Arm Error"<<endl; 
  }
  else
  {
    arm= "1";
  }

  //8check imu (8)
  Duration diffimu=Time::now()-imu_time;
  if(diffimu.toSec() > 5)
  {
    imu = "0";error = true;
    sosID.push_back(sos_ref[8]);  
    sosID_enum.push_back(8);  
    cout<<"SOS!: IMU Error"<<endl;
  }
  else
  {
    imu = "1";
  }
  
  //9check tray (9)
  Duration difftray=Time::now()-tray_time;
  if(difftray.toSec() > 5)
  {
    tray = "0";error = true;
    sosID.push_back(sos_ref[9]); 
    sosID_enum.push_back(9);  
    cout<<"SOS!: Tray Sensor Error"<<endl; 
  }
  else
  {
    tray = "1";
  }

  //10check tower camera (10)
  Duration difftcam=Time::now()-tcam_time;
  if(difftcam.toSec() > 5)
  {
    tcam = "0";error = true;
    sosID.push_back(sos_ref[10]); 
    sosID_enum.push_back(10);  
    cout<<"SOS!: Tower Camera Error"<<endl; 
  }
  else
  {
    tcam = "1";
  }

  //-------------------------------operation Error SOS only------------

  //11check offline (11)
  
  if(OfflineSOS)
  {
    error = true;
    sosID.push_back(sos_ref[11]); 
    sosID_enum.push_back(11);  
    ROS_INFO("SOS!: Offline Error");
  }
  

  //12check obstacle_short (12)
  Duration diffobs=Time::now()-obs_t;
  if(diffobs.toSec() > 5)//timeout if no obstacle detected in 5s
  {
    stopobs=false;
  }
  else//if detected under 5s. keep true
  {
    stopobs=true;
  }
  if(stopobs)//while true
  {
    Duration durofobs=Time::now()-obs_t;
    if(durofobs.toSec() > 2 && durofobs.toSec() <= 30)
    { //if obstacle keep on detected between 5s to 30s
      Duration alertobs=Time::now()-alert_t;
      if(alertobs.toSec() > 5)//shoot alert every 5s only
      {
        //12check obstacle_short (12)
        error = true;
        sosID.push_back(sos_ref[12]); 
        sosID_enum.push_back(12);   
        alert_t = Time::now();  
        cout<<"SOS!: Obstacle Short Error"<<endl;   
      }

    }
    else if(durofobs.toSec() > 30)//if occure more than 30s
    { //if obstacle keep on detected more 30s
      //13check obstacle_long (13)
      error = true;
      sosID.push_back(sos_ref[13]); 
      sosID_enum.push_back(13); 
      cout<<"SOS!: Obstacle Long Error"<<endl;
    }

  }


  //14check rain (14)
  if(HumidSOS)
  {
    error = true;
    sosID.push_back(sos_ref[14]); 
    sosID_enum.push_back(14);  
    cout<<"SOS!: Rain Error"<<endl;
  }
  

  //15high humidity (15)
  if(RainSOS)
  {
    error = true;
    sosID.push_back(sos_ref[15]); 
    sosID_enum.push_back(15);  
    cout<<"SOS!: Humidity Error"<<endl;
  }

  //16check emergency button (16)
  if(esw == "0")
  {
    error = true;
    sosID.push_back(sos_ref[16]); 
    sosID_enum.push_back(16);  
    ROS_INFO("SOS!: Emergency Button Error");
  }

  //17container_perr (17)
  if(PickError)
  {
    error = true;
    sosID.push_back(sos_ref[17]);  
    sosID_enum.push_back(17); 
    cout<<"SOS!: Container Pick Error"<<endl;
  }

  //18container_derr (18)
  if(DropError)
  {
    error = true;
    sosID.push_back(sos_ref[18]);  
    sosID_enum.push_back(18);  
    cout<<"SOS!: Container Drop Error"<<endl;
  }

  //19container_dfail(19)
  if(DropFail)
  {
    error = true;
    sosID.push_back(sos_ref[19]); 
    sosID_enum.push_back(19);   
    cout<<"SOS!: Container Drop Fail"<<endl;
  }

  //20container_pfail (20)
  if(PickFail)
  {
    error = true;
    sosID.push_back(sos_ref[20]);  
    sosID_enum.push_back(20);  
    cout<<"SOS!: Container Pick Fail"<<endl;
  }


  //21junction  (21)
  if(juncfound)
  {
    error = true;
    sosID.push_back(sos_ref[21]);  
    sosID_enum.push_back(21);  
    cout<<"SOS!: Junction Error"<<endl;
  }

  //22no_table (22)
  if(NoTableError)
  {
    error = true;
    sosID.push_back(sos_ref[22]);  
    sosID_enum.push_back(22); 
    cout<<"SOS!: No Table Error"<<endl; 
  }


  //23no_charger (23)
  if(NoChargerError)
  {
    error = true;
    sosID.push_back(sos_ref[23]);  
    sosID_enum.push_back(23); 
    cout<<"SOS!: No Charger Error"<<endl; 
  }

  //24no_exit (24)
  if(NoExit)
  {
    error = true;
    sosID.push_back(sos_ref[24]); 
    sosID_enum.push_back(24);   
    cout<<"SOS!: No Exit Error"<<endl;
  }
  

  //25move_error (25)
  if(abs(distENC - distPXY) > MoveSOS_XYtoENC_Err)
  {
    error = true;
    sosID.push_back(sos_ref[25]); 
    sosID_enum.push_back(25);   
    cout<<"SOS!: Move Error"<<endl;
  }
  

  // //26low battery (26)
  if(lowbatt=="0")
  {
    error = true;
    sosID.push_back(sos_ref[26]);  
    sosID_enum.push_back(26);  
    ROS_INFO("SOS!: Low Battery");
  }


  //SOS RESPONSE AND NOTIFICATION
  if(error)//reset 
  {
  
    sos_notify("0");
    publish_diagnostic();

  }
}

void generic_check()
{
  //check online
  isOnline();


  //check junction
  JsonArray& msjunc = msstObj["junc"];
  for(int x = 0; x<msjunc.size();x++)
  {
    string sx = msjunc [x]["x"].as<string>();
    float px = atof(sx.c_str());
    string sy = msjunc [x]["y"].as<string>();
    float py = atof(sy.c_str());

    float djx = atof(ptsX.c_str())-px;
    float djy = atof(ptsY.c_str())-py;
    float distjxy = sqrt(pow(djx,2)+pow(djy,2));

    if(distjxy<junc_offset)
    {
      suspend = true;
      cout<<"Suspended on Junction"<<endl;
      juncfound = true;
    }

  }

  //override at operation point
  string lt = msstptxy_ref[ms_cnt]["arm"]["cmd"].as<string>();
  string first_four = lt.substr(0, 4);
  string ms_x = msstptxy_ref[ms_cnt]["x"].as<string>();
  string ms_y = msstptxy_ref[ms_cnt]["y"].as<string>();
  // if(msstptxy_ref.as<string>() != "")
    // cout <<"AMCL_X:"<< ptsX<<endl;
    // cout <<"AMCL_Y:"<< ptsY<<endl;
    // cout <<"TargetPoint_X:"<< ms_x<<endl;
    // cout <<"TargetPoint_Y:"<< ms_y<<endl;
    float dx = atof(ptsX.c_str())-atof(ms_x.c_str());
    float dy = atof(ptsY.c_str())-atof(ms_y.c_str());
    float distxy = sqrt(pow(dx,2)+pow(dy,2));
    // cout<< "Diff_CMsquare:"<<distxy<<endl;
    String m;
    if(distxy<junc_offset)
    {     
      m.data = "pickdrop";
      reg_pub.publish(m);
    }
    else
    {
      m.data = "normal";
      reg_pub.publish(m);    
    }



  //check charging condition
  if(needcharge == "1" && found_charger==true)//if in charging mode
  {
    if(atof(batt.c_str()) > max_charge)//check current battery
    {
      needcharge = "0";
    }
  }

  //Execution of suspend and Resume
  if (suspend)
  {
    if(STATE != "SUSPEND" && cur_state != "SUSPEND")
    {
      callstate("SUSPEND");
    }
    sr_break_pub.publish(sr_break);
    sr_led = 1;
    SR = "1";//FMS SR status
    //cout << "Suspend -- Suspend -- Suspend -- Suspend --Suspend "<<Time::now()<< endl;
    sus_pub.publish(SR);
  }
  else
  { 
    sr_led = 0;
    SR = "0";//FMS SR status
    sus_pub.publish(SR);
    //cout << "Move -- Move -- Move -- Move -- Move -- Move -- Move -- Move " << endl;
  }

  esw_pub.publish(esw);
  needcharge_pub.publish(needcharge);

}

void ledpub()
{
  String strt;
  strt.data = sr_led;
  led_pub.publish(strt);
}



//---------------------------------------------------------CALLBACKS---------------------------------------

//process and publish the diagnostic data to FMS when requested
void sys_diag_Callback(const std_msgs::String::ConstPtr& msg)
{
  // {"agv_ID" : "1",    "cmd"  : "1" }
  string out = msg->data.c_str();
  DynamicJsonBuffer jsonBufferSysDiag;
  JsonObject& doc = jsonBufferSysDiag.parseObject(out);
  //cout<<doc["agv_ID"].as<string>()<<endl; success output:1
  if(doc["agv_ID"]==AGV_ID)
  {
    //cout<<"in"<<endl;  success output:in

    if(doc["cmd"]=="1")
    {
      publish_diagnostic();
      cout<<"FMS request diagnostic..."<<endl;
    }
  }
}

void lidar3Callback(const sensor_msgs::PointCloud2::ConstPtr& msg)
{
  lidar3_time = Time::now();
}

void lidar2fCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
{
  lidar2f_time = Time::now();
}

void lidar2rCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
{
  lidar2r_time = Time::now();
}

void camCallback(const sensor_msgs::Image::ConstPtr& msg)
{
  cam_time = Time::now();
}

void obuCallback(const std_msgs::String::ConstPtr& msg)
{
  obu_time = Time::now();

  string sr_data = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferObu;
  JsonObject& readObj = jsonReadBufferObu.parseObject(sr_data);



  if(readObj["envPM25"] == NULL)
  {
    obu_temp = readObj["temperature"].as<string>();  
    obu_id = readObj["obu_ID"].as<string>();
  }

  if(readObj["temperature"] == NULL)
  {
    env_temp = readObj["envTemperature"].as<string>();
    humid = readObj["envHumidity"].as<string>();
    rain = readObj["rainfallIntensity"].as<string>();
    if(atoi(humid.c_str())>= HighHumidity)
    {
      HumidSOS = true;
    }
    if(atoi(rain.c_str())>= RainFall)
    {
      RainSOS=true;
    }

  }
}

//void armCallback(const std_msgs::String::ConstPtr& msg)
void armCallback(const geometry_msgs::PoseStamped::ConstPtr& msg)
{
  arm_time = Time::now();
}

void tcamCallback(const std_msgs::String::ConstPtr& msg)
{
  tcam_time = Time::now();
}

void trayCallback(const std_msgs::String::ConstPtr& msg)
{
  tray_time = Time::now();
}

void ObjectRecogCallback(const std_msgs::String::ConstPtr& msg)
{
  tray_time = Time::now();
  cur_obj_detected = msg->data.c_str();
}

//process and publish the health data to FMS periodically
//including all Suspend Resume stat
void agv_health_pub(const std_msgs::String::ConstPtr& msg)
{
  //get health data from here and there
  llc_time = Time::now();
  //publish it
  string sr_data = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferHealth;
  DynamicJsonBuffer jsonWriteBufferHealth;
  JsonObject& readObj = jsonReadBufferHealth.parseObject(sr_data);

  if(readObj.success())
  {
    // cout<<readObj<<endl; success output: ___
    JsonObject& root = jsonWriteBufferHealth.createObject();
    root["agv_ID"] = AGV_ID;
    // cout<<root<<endl; success output: {"agv_ID":"1"}
    string tmpRenc = readObj["ENC?"][0];
    string tmpLenc = readObj["ENC?"][2];

    float encR = atof(tmpRenc.c_str());
    float encL = atof(tmpLenc.c_str());

    distENC = sqrt(pow(encL-last_encL,2)+pow(encR-last_encR,2));
    last_encR = encR;
    last_encL = encL;

    string motorX = readObj["MOV?"][0];
    string motorZ = readObj["MOV?"][1];

    if(tmpRenc != ""){ enc_r = "1"; }

    else { enc_r = "0"; }

    if(tmpLenc != ""){ enc_l = "1"; }

    else { enc_l = "0"; }

    string tmpRT = readObj["STA?"][1];
    string tmpLT = readObj["STA?"][6];

    if(tmpRT != ""){ mot_r = "1"; }

    else { mot_r = "0"; }

    if(tmpLT!= ""){ mot_l = "1"; }

    else { mot_l = "0"; }

    string rawBatt = readObj["STA?"][0];
    
    batt = rawBatt;
    batt_int = atoi(batt.c_str());

    float bm = (float(batt_int-41))/15*100;
    ostringstream btw;
    btw << fixed<<setprecision(1)<<bm;
    root["batt"] = btw.str();


    string mmb = btw.str();
    if(atof(mmb.c_str()) < low_charge)
    {
    	batt_cnt++;
    }
    else
    {
    	batt_cnt=0;     	
    }

    if(batt_cnt >50)
    {
    	batt_cnt=0;   
    	needcharge = "1";
      	lowbatt = "0";
	}
	else
	{
		lowbatt = "1";
	}

    JsonObject& msObj = root.createNestedObject("ms");
    msObj["ms_ID"] = ms_id;
    msObj["sched_ID"] = sched_id;
    msObj["ss_id"] = ss_id;


    msObj["act_Seq"] = msstptxy_ref[ms_cnt]["Seq"].as<string>();
    msObj["point"] = msstptxy_ref[ms_cnt]["pt"].as<string>();
    msObj["act"] = ms_act;


    root["charge"]=needcharge;
    root["SR"]=SR;

    JsonObject& msObj2 = root.createNestedObject("loc");
    msObj2["lat"]=cur_lat;
    msObj2["long"]=cur_long;

    JsonObject& msObj3 = root.createNestedObject("pnt");
    msObj3["x"]=ptsX;
    msObj3["y"]=ptsY;

    JsonObject& msObj4 = root.createNestedObject("spd");
    msObj4["x"]=motorX;
    msObj4["z"]=motorZ;

    JsonObject& msObj5 = root.createNestedObject("tmp");
    msObj5["l"]=tmpLT;
    msObj5["r"]=tmpRT;

    string tmpobu;
    root.printTo(tmpobu);
    String stobu;
    stobu.data = tmpobu;


    JsonObject& msObj7 = root.createNestedObject("obu");
    msObj7["env_temp"]=env_temp;
    msObj7["humid"]=humid;
    msObj7["obu_id"]=obu_id;
    msObj7["obu_temp"]=obu_temp;
    msObj7["rainfallintensity"]=rain;

    string tmpstr;
    root.printTo(tmpstr);
    String strt;
    strt.data = tmpstr;

    Duration diff_c=Time::now()-health_t;
    if(diff_c.toSec() > 1)
    {
      //cout<<strt<<endl;
      health_pub.publish(strt);
      to_obu_pub.publish(stobu);
      health_t = Time::now();

    }
  }

}

void sys_sos_Callback(const std_msgs::String::ConstPtr &msg){
  string off = msg->data.c_str();
  DynamicJsonBuffer jsonReadBufferOff;
  JsonObject& readObjO = jsonReadBufferOff.parseObject(off);

  if (readObjO["agv_ID"]==AGV_ID)//check ID
  {
    if(readObjO["sos_ID"] == sos_ref[26])//if it is override
    {
      sos_notify(readObjO["sos_ID"]);//for notification
      sos_trigger_response_str(readObjO["res"]);//response
    }
  }
}

void gpsCallback(const sensor_msgs::NavSatFixConstPtr& msg)
{
  char lt[30];
  char lg[30];
  sprintf(lg,"%.25f",msg->longitude);
  sprintf(lt,"%.25f",msg->latitude);

  string xlg(lg);
  string xlt(lt);
  cur_long = xlg;
  cur_lat = xlt;

}

void ptsCallback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msgAMCL){
  ostringstream px,py;
  float pX = msgAMCL->pose.pose.position.x;
  float pY = msgAMCL->pose.pose.position.y;
  px << pX;
  py << pY;
  ptsX = px.str();
  ptsY = py.str();

  distPXY = sqrt(pow(pX-last_pX,2)+pow(pY-last_pY,2));

  last_pX = pX;
  last_pY = pY;

}

void obstacleCallback(const std_msgs::String::ConstPtr &msg)
{
  string Data = msg->data.c_str();
  if(Data == "obstacle")
  {
    if(stopobs==false)
    {
      obs_t = Time::now();
    }
  }
}

void state_Callback(const atlas80evo_msgs::FSMState &msg)
{
 STATE = msg.state;
 // cout<<"--------------------------------"<<STATE<<endl;
}

void nanocallback(const std_msgs::String::ConstPtr& msg) 
{
	string srt_data = msg->data.c_str();
	DynamicJsonBuffer jsonReadBuffernano;
	JsonObject& readnano = jsonReadBuffernano.parseObject(srt_data);

	//emergency switch
    ostringstream sesw;
    sesw << readnano["DMI?"][4];
    esw = sesw.str();


	Duration diff_sus=Time::now()-sus_t;
	if(diff_sus.toSec() > 1 && readnano["DMI?"][5] == 0 && readnano["DMI?"][5] == SR_SW)
	{
		SR_SW = readnano["DMI?"][5];
		suspend = !suspend;
		sus_t = Time::now();

		if(cur_state == "SUSPEND")
		{
			String tz;
			tz.data = "resume";
			armxtra_pub.publish(tz);

			if(cur_arm != "")
			{
			  String armove;
			  armove.data = cur_arm;
			  arm_pub.publish(armove);
			}

			callstate(before_state);
		}
		else
		{
			String ta;
			ta.data = "suspend";
			armxtra_pub.publish(ta);
		}

	}
    
}

void srCallback(const std_msgs::String::ConstPtr &msg)
{
  string Data = msg->data.c_str();
  if(Data == "1")
  {
  	suspend = !suspend;
  }
  else if(Data == "0")
  {
	suspend = !suspend;
    callstate(before_state);
  }
}

void msstCallback(const std_msgs::String::ConstPtr &msg)
{
  if(ms_act=="done")
  {
    string Data = msg->data.c_str();
    msstObj = msstobj_Buffer.parseObject(Data);
    ms_id = msstObj["ms_ID"].as<string>();
    sched_id = msstObj["sched_ID"].as<string>();
    ss_id = msstObj["ss_ID"].as<string>();

    JsonArray& msstptxy = msstObj["activity"];
  	msstptxy_ref = msstptxy;
  }

}

void mscntCallback(const std_msgs::Int32::ConstPtr &msg)
{
  ms_cnt = msg->data;
  
}

void msarmCallback(const std_msgs::String::ConstPtr &msg)
{
  cur_arm = msg->data;
  
}

void msactCallback(const std_msgs::String::ConstPtr &msg)
{
  ms_act = msg->data.c_str();
  if(ms_act == "done")
  {
  	    cout<<"ALL DONE"<<endl;
        cur_arm = "";
        ms_cnt = 0;
        ms_id = "";
        ms_seq = "";
        ss_id = "";
        sched_id = "";
        msstObj = 0;
  }
}


void sosCallback(const std_msgs::String::ConstPtr &msg)
{
  string sos = msg->data.c_str();
  if(sos== "no_exit")
  {
  	   NoExit = true;
  }
}

int main(int argc, char **argv)
{

  ros::init(argc, argv, "fms_sos");
  ros::NodeHandle nh;

  sr_break.linear.x = sr_break.linear.y = sr_break.linear.z = 0.0;
  sr_break.angular.x = sr_break.angular.y = sr_break.angular.z = 0.0;

  //From FSM
  Subscriber sys_sos = nh.subscribe("/f2a/sys/sos", 100, sys_sos_Callback);
  Subscriber sys_diag = nh.subscribe("/f2a/sys/diag", 100, sys_diag_Callback);
  Subscriber healthSubs = nh.subscribe("/low_level/status", 100, agv_health_pub);
  Subscriber msstSubs = nh.subscribe("/f2a/ms/st", 100, msstCallback);

  //From System For SOS and Diagnostic
  Subscriber gpsSubs = nh.subscribe("/vectornav/GPS", 5, gpsCallback);
  Subscriber traySubs = nh.subscribe("/a2f/arm/tray", 100, trayCallback);
  Subscriber obstacleSubs = nh.subscribe("/a2a/obstacle", 100, obstacleCallback);
  Subscriber lidar3Subs = nh.subscribe("/os1_cloud_node/points", 100, lidar3Callback);//listen 3D lidar
  Subscriber lidar2fSubs = nh.subscribe("/cloud1", 100, lidar2fCallback);//listen 2D Lidar f
  Subscriber lidar2rSubs = nh.subscribe("/cloud2", 100, lidar2rCallback);//listen 2D Lidar r
  Subscriber camSubs = nh.subscribe("/camera/color/image_raw", 100, camCallback);//listen camera
  Subscriber obuSubs = nh.subscribe("/a2a/obu", 100, obuCallback);//listen obu
  Subscriber armSubs = nh.subscribe("/a2a/arm/live", 100, armCallback);//listen arm location
  Subscriber ptsSubs = nh.subscribe("/amcl_pose", 1000, ptsCallback);

  //From System For Operation
  Subscriber state = nh.subscribe("/fsm_node/state", 100, state_Callback);
  Subscriber srtSubs = nh.subscribe("/led/status", 1000, nanocallback);

  //FMS_Handler
  Subscriber mscntSubs = nh.subscribe("/a2a/ms/cnt", 100, mscntCallback);
  Subscriber msactSubs = nh.subscribe("/a2a/ms/act", 100, msactCallback);
  Subscriber msarmSubs = nh.subscribe("/a2a/ms/arm", 100, msarmCallback);
  Subscriber srSubs = nh.subscribe("/a2a/ms/sr", 100, srCallback);
  Subscriber sosSubs = nh.subscribe("/a2a/ms/sos", 1000, sosCallback);
  
  //To FMS_Handler
  esw_pub = nh.advertise<String>("/a2a/ms/esw", 100);
  abort_pub = nh.advertise<String>("/a2a/ms/abort", 100);
  needcharge_pub = nh.advertise<String>("/a2a/ms/needcharge", 100);
  

  //To System For Operation
  reg_pub = nh.advertise<String>("/pd_state", 100);
  sus_pub = nh.advertise<String>("/a2a/led",100);
  sr_break_pub = nh.advertise<geometry_msgs::Twist>("/twist_cmd_mux/input/suspend", 10);
  to_obu_pub = nh.advertise<String>("/a2a/to_obu", 100);

  //To FMS
  sos_pub = nh.advertise<String>("/a2f/sys/sos", 100);
  diag_pub = nh.advertise<String>("/a2f/sys/diag", 100);

  //Service Client
  playsound = nh.serviceClient<atlas80evo_msgs::SetSound>("/sound/call");
  stateClient = nh.serviceClient<atlas80evo_msgs::SetFSMState>("/fsm_node/set_state");
  

  Rate loop_rate(20);
  cout << ver << endl;
  health_t = Time::now();
  wait_t = Time::now();
  sus_t = Time::now();
  waita_t = Time::now();
  alert_t = Time::now();
  cam_time = Time::now();

  while(ok())
  {
    sos_check();
    generic_check();
    spinOnce();
    loop_rate.sleep();
  }
  return 0;
}