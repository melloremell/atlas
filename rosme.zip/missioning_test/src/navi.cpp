// header for ros
#include "ros/ros.h"
// message
#include "std_msgs/String.h"

#include "ArduinoJson.h"
#include <iostream>
#include <sstream>

using namespace std;
using namespace std_msgs;
using namespace ros;

ros::Publisher ear_pub;
// callback function that will received a message when chatter topic is triggered
void chatterCallback(const std_msgs::String::ConstPtr& msg){

  ros::Duration(5).sleep();
  string Data = msg->data.c_str();
  DynamicJsonBuffer jsonReadBuffer;
  JsonObject& readObj = jsonReadBuffer.parseObject(Data);
  cout<<"received"<<readObj<<endl;

  DynamicJsonBuffer navBuffer;
  JsonObject& nobj = navBuffer.createObject();

  nobj["st"] = "0";

  nobj ["act"] = "move";

  string root2;
  nobj.printTo(root2);
  String s;
  s.data = root2;
  cout<<"to_fms handeller"<<s<<endl;
  ear_pub.publish(s);
}

int main(int argc, char **argv){
    // initiallize ROS (specify name for remapping) (unique node)
    ros::init(argc, argv, "navi");

    // create handle
    ros::NodeHandle n;

    // subscribe to chatter topic
    ros::Subscriber sub = n.subscribe("/a2a/nav", 1000, chatterCallback);

    ear_pub = n.advertise<std_msgs::String>("/a2a/ms/hdl",1000);

    ros::spin();

    return 0;
}
